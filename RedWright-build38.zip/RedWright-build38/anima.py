"""Anima text-to-image. Kept off the Stable Diffusion path.

Base, Aesthetic, and Turbo are 2B Cosmos DiTs. They need the Qwen3 0.6B
text encoder and the Qwen-Image VAE. Flow-match Euler uses shift 3.
Base and Aesthetic want about 30 steps and CFG 4. Turbo wants CFG 1 and
about 10 steps. A bigger 2.9B or 3.8B merge is loaded when its block count
differs from the 28-block base.
"""

from __future__ import annotations

import os
import subprocess
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TOOLS = ROOT / "anima_tools"
TOKEN_ROOT = ROOT / "anima_tokenizers"
WEIGHTS = {
    "text": (
        "qwen_3_06b_base.safetensors",
        "https://huggingface.co/circlestone-labs/Anima/resolve/main/split_files/text_encoders/qwen_3_06b_base.safetensors",
        800_000_000,
    ),
    "vae": (
        "qwen_image_vae.safetensors",
        "https://huggingface.co/circlestone-labs/Anima/resolve/main/split_files/vae/qwen_image_vae.safetensors",
        150_000_000,
    ),
}
TOKEN_FILES = (
    "tokenizer/tokenizer.json",
    "tokenizer/tokenizer_config.json",
    "tokenizer/chat_template.jinja",
    "t5_tokenizer/tokenizer.json",
    "t5_tokenizer/tokenizer_config.json",
)
TOKEN_URL = "https://huggingface.co/circlestone-labs/Anima-Base-v1.0-Diffusers/resolve/main/"


def snap_dim(value: int) -> int:
    clamped = max(512, min(1536, int(value)))
    return clamped - (clamped % 32)


def preset_values(name: str) -> tuple[int, float]:
    if name == "Turbo":
        return 10, 1.0
    return 30, 4.0


_PROBE = """
import sys
import traceback
print("python", sys.executable)
try:
    import torch
    print("torch", torch.__version__)
except Exception:
    print("torch import failed")
    traceback.print_exc()
try:
    import transformers
    print("transformers", transformers.__version__)
except Exception:
    print("transformers import failed")
    traceback.print_exc()
try:
    import diffusers
    print("diffusers", getattr(diffusers, "__version__", "?"), diffusers.__file__)
    from diffusers import AnimaAutoBlocks
    print("AnimaAutoBlocks", AnimaAutoBlocks.__name__)
except Exception:
    print("Anima import failed")
    traceback.print_exc()
    raise SystemExit(1)
"""


def _runtime_env() -> dict:
    env = os.environ.copy()
    previous = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(ROOT / "anima_runtime") + (os.pathsep + previous if previous else "")
    return env


def _probe(python: str, env: dict) -> tuple[bool, str]:
    result = subprocess.run([python, "-c", _PROBE], capture_output=True, text=True, env=env)
    detail = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
    return result.returncode == 0, detail[-2500:]


def runtime(status=None) -> tuple[str, dict]:
    python = sys.executable
    env = _runtime_env()
    ok, _detail = _probe(python, env)
    if ok:
        return python, env
    if status:
        status("Installing the Anima runtime into the app folder. This happens once and can take several minutes.")
    target = ROOT / "anima_runtime"
    target.mkdir(parents=True, exist_ok=True)
    command = [
        python,
        "-m",
        "pip",
        "install",
        "--upgrade",
        "--target",
        str(target),
        "--no-deps",
        "https://github.com/huggingface/diffusers/archive/refs/heads/main.zip",
        "transformers>=4.57",
        "huggingface-hub>=0.34",
        "tokenizers>=0.22",
        "safetensors",
        "regex",
        "tqdm",
        "pyyaml",
        "packaging",
        "filelock",
        "requests",
        "fsspec",
        "httpx",
        "typing_extensions",
        "sentencepiece",
        "protobuf",
        "accelerate",
    ]
    installed = subprocess.run(command, capture_output=True, text=True)
    if installed.returncode != 0:
        tail = ((installed.stdout or "") + "\n" + (installed.stderr or "")).strip()
        raise RuntimeError(tail[-2500:] or "pip could not install the Anima runtime.")
    ok, detail = _probe(python, env)
    if not ok:
        raise RuntimeError(detail or "AnimaAutoBlocks still did not import.")
    return python, env


def weight_path(kind: str) -> Path:
    return ROOT / WEIGHTS[kind][0]


def _download_file(url: str, dest: Path, minimum: int, status) -> None:
    part = dest.with_name(dest.name + ".part")
    if status:
        status(f"Downloading {dest.name} into the app folder")
    request = urllib.request.Request(url, headers={"User-Agent": "RedWright"})
    with urllib.request.urlopen(request, timeout=60) as response, part.open("wb") as handle:
        total = int(response.headers.get("Content-Length") or 0)
        done = 0
        reported = -1
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            handle.write(chunk)
            done += len(chunk)
            if status and total:
                percent = int(done * 100 / total)
                if percent >= reported + 10:
                    reported = percent
                    status(f"{dest.name} {percent}%")
    if not part.is_file() or part.stat().st_size < minimum:
        part.unlink(missing_ok=True)
        raise RuntimeError(f"{dest.name} did not finish downloading.")
    part.replace(dest)


def ensure_weights(status=None) -> tuple[Path, Path]:
    saved = []
    for kind in ("text", "vae"):
        name, url, minimum = WEIGHTS[kind]
        dest = ROOT / name
        if dest.is_file() and dest.stat().st_size >= minimum:
            saved.append(dest)
            continue
        if dest.is_file():
            dest.unlink()
        _download_file(url, dest, minimum, status)
        saved.append(dest)
    return saved[0], saved[1]


def _download_tokenizers(status) -> tuple[Path, Path]:
    for name in TOKEN_FILES:
        dest = TOKEN_ROOT / name
        if dest.is_file() and dest.stat().st_size > 0:
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        if status:
            status(f"Downloading {name}")
        request = urllib.request.Request(TOKEN_URL + name, headers={"User-Agent": "RedWright"})
        with urllib.request.urlopen(request, timeout=120) as response:
            dest.write_bytes(response.read())
    return TOKEN_ROOT / "tokenizer", TOKEN_ROOT / "t5_tokenizer"


def _block_count(state: dict) -> int:
    import re

    found = set()
    for key in state:
        match = re.search(r"blocks\.block(\d+)", key)
        if match:
            found.add(int(match.group(1)))
    return (max(found) + 1) if found else 28


def _load_split(model: Path, text: Path, vae: Path, shift: float, dtype):
    import torch
    from safetensors.torch import load_file

    sys.path.insert(0, str(TOOLS))
    from convert_anima_to_diffusers import (  # noqa: WPS433
        convert_qwen_image_vae,
        convert_text_conditioner,
        convert_text_encoder,
        split_anima_transformer_checkpoint,
    )
    from convert_cosmos_to_diffusers import TRANSFORMER_CONFIGS, convert_transformer
    from diffusers import AnimaAutoBlocks, FlowMatchEulerDiscreteScheduler
    from transformers import AutoTokenizer, T5TokenizerFast

    dit_state = load_file(str(model), device="cpu")
    transformer_state, conditioner_state = split_anima_transformer_checkpoint(dit_state)
    layers = _block_count(transformer_state)
    TRANSFORMER_CONFIGS["Cosmos-2.0-Diffusion-2B-Text2Image"]["num_layers"] = layers
    transformer = convert_transformer("Cosmos-2.0-Diffusion-2B-Text2Image", state_dict=transformer_state, weights_only=True)
    text_encoder = convert_text_encoder(load_file(str(text), device="cpu"))
    vae_model = convert_qwen_image_vae(load_file(str(vae), device="cpu"))
    conditioner = convert_text_conditioner(conditioner_state)
    qwen_dir, t5_dir = _download_tokenizers(None)
    pipe = AnimaAutoBlocks().init_pipeline()
    pipe.update_components(
        text_encoder=text_encoder.to(dtype=dtype),
        tokenizer=AutoTokenizer.from_pretrained(str(qwen_dir)),
        t5_tokenizer=T5TokenizerFast.from_pretrained(str(t5_dir)),
        text_conditioner=conditioner.to(dtype=dtype),
        transformer=transformer.to(dtype=dtype),
        vae=vae_model.to(dtype=dtype),
        scheduler=FlowMatchEulerDiscreteScheduler(shift=shift),
    )
    return pipe


def _load_folder(folder: Path, shift: float, dtype):
    from diffusers import FlowMatchEulerDiscreteScheduler, ModularPipeline

    pipe = ModularPipeline.from_pretrained(str(folder))
    pipe.load_components(torch_dtype=dtype)
    pipe.scheduler = FlowMatchEulerDiscreteScheduler(shift=shift)
    return pipe


def _attach_loras(pipe, loras: list) -> None:
    names = []
    weights = []
    for index, item in enumerate(loras or []):
        path, weight = item[0], float(item[1])
        if not path:
            continue
        name = f"anima{index}"
        pipe.load_lora_weights(path, adapter_name=name)
        names.append(name)
        weights.append(weight)
    if names:
        pipe.set_adapters(names, adapter_weights=weights)


def draw(job: dict, write, on_preview=None) -> None:
    import torch
    from PIL import Image

    write("load")
    model = Path(job["model"])
    shift = float(job.get("shift") or 3)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.bfloat16 if device == "cuda" and torch.cuda.is_bf16_supported() else torch.float16
    if model.is_dir():
        pipe = _load_folder(model, shift, dtype)
    else:
        text = Path(job.get("text") or "")
        vae = Path(job.get("vae") or "")
        if not text.is_file() or not vae.is_file():
            raise RuntimeError("Anima needs the Qwen3 0.6B text encoder and the Qwen-Image VAE, or a diffusers folder.")
        _download_tokenizers(write)
        pipe = _load_split(model, text, vae, shift, dtype)
    _attach_loras(pipe, job.get("loras") or [])
    try:
        pipe.enable_model_cpu_offload()
    except Exception:
        pipe.to(device)
    steps = int(job["steps"])
    seed = job.get("seed")
    generator = None
    if seed is not None:
        generator = torch.Generator(device=device).manual_seed(int(seed))
    kwargs = {
        "prompt": job.get("prompt") or "",
        "negative_prompt": job.get("negative") or "",
        "num_inference_steps": steps,
        "guidance_scale": float(job.get("cfg") or 4),
        "height": int(job["height"]),
        "width": int(job["width"]),
        "max_sequence_length": int(job.get("max_length") or 512),
        "generator": generator,
    }
    source = str(job.get("init_image") or "")
    if source and Path(source).is_file():
        kwargs["image"] = Image.open(source).convert("RGB")
        kwargs["strength"] = float(job.get("init_denoise") or 0.6)
    write(f"Step 0 / {steps}")
    result = pipe(**{key: value for key, value in kwargs.items() if value is not None})
    images = getattr(result, "images", None)
    if images is None and isinstance(result, dict):
        images = result.get("images")
    if not images:
        raise RuntimeError("Anima did not return a picture.")
    image = images[0]
    Path(job["out"]).parent.mkdir(parents=True, exist_ok=True)
    image.save(job["out"])
    if on_preview is not None:
        on_preview(image, "Final")
    write("done")
