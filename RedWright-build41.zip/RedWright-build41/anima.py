"""Anima text-to-image. Kept off the Stable Diffusion path.

Base, Aesthetic, and Turbo are 2B Cosmos DiTs. They need the Qwen3 0.6B
text encoder and the Qwen-Image VAE. Flow-match Euler uses shift 3.
Base and Aesthetic want about 30 steps and CFG 4. Turbo wants CFG 1 and
about 10 steps. A bigger 2.9B or 3.8B merge is loaded when its block count
differs from the 28-block base.
"""

from __future__ import annotations

import os
import subprocess
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TOOLS = ROOT / "anima_tools"
TOKEN_ROOT = ROOT / "anima_tokenizers"
WEIGHTS = {
    "text": (
        "qwen_3_06b_base.safetensors",
        "https://huggingface.co/circlestone-labs/Anima/resolve/main/split_files/text_encoders/qwen_3_06b_base.safetensors",
        800_000_000,
    ),
    "vae": (
        "qwen_image_vae.safetensors",
        "https://huggingface.co/circlestone-labs/Anima/resolve/main/split_files/vae/qwen_image_vae.safetensors",
        150_000_000,
    ),
}
TOKEN_FILES = (
    "tokenizer/tokenizer.json",
    "tokenizer/tokenizer_config.json",
    "tokenizer/chat_template.jinja",
    "t5_tokenizer/tokenizer.json",
    "t5_tokenizer/tokenizer_config.json",
)
TOKEN_URL = "https://huggingface.co/circlestone-labs/Anima-Base-v1.0-Diffusers/resolve/main/"


def snap_dim(value: int) -> int:
    clamped = max(512, min(1536, int(value)))
    return clamped - (clamped % 32)


def preset_values(name: str) -> tuple[int, float]:
    if name == "Turbo":
        return 10, 1.0
    return 30, 4.0


_PROBE = """
import sys
import traceback
print("python", sys.executable)
try:
    import torch
    print("torch", torch.__version__)
except Exception:
    print("torch import failed")
    traceback.print_exc()
try:
    import transformers
    print("transformers", transformers.__version__)
except Exception:
    print("transformers import failed")
    traceback.print_exc()
try:
    import diffusers
    print("diffusers", getattr(diffusers, "__version__", "?"), diffusers.__file__)
    from diffusers import AnimaAutoBlocks
    print("AnimaAutoBlocks", AnimaAutoBlocks.__name__)
except Exception:
    print("Anima import failed")
    traceback.print_exc()
    raise SystemExit(1)
"""


def _runtime_env() -> dict:
    env = os.environ.copy()
    previous = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(ROOT / "anima_runtime") + (os.pathsep + previous if previous else "")
    return env


def _probe(python: str, env: dict) -> tuple[bool, str]:
    result = subprocess.run([python, "-c", _PROBE], capture_output=True, text=True, env=env)
    detail = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
    return result.returncode == 0, detail[-2500:]


def runtime(status=None) -> tuple[str, dict]:
    python = sys.executable
    env = _runtime_env()
    ok, _detail = _probe(python, env)
    if ok:
        return python, env
    if status:
        status("Installing the Anima runtime into the app folder. This happens once and can take several minutes.")
    target = ROOT / "anima_runtime"
    target.mkdir(parents=True, exist_ok=True)
    command = [
        python,
        "-m",
        "pip",
        "install",
        "--upgrade",
        "--target",
        str(target),
        "--no-deps",
        "https://github.com/huggingface/diffusers/archive/refs/heads/main.zip",
        "transformers>=4.57",
        "huggingface-hub>=1.0",
        "tokenizers>=0.22",
        "safetensors",
        "regex",
        "tqdm",
        "pyyaml",
        "packaging",
        "filelock",
        "requests",
        "fsspec",
        "httpx2",
        "httpcore2",
        "anyio",
        "idna",
        "truststore",
        "typing_extensions",
        "sentencepiece",
        "protobuf",
        "accelerate",
        "peft>=0.17.0",
    ]
    installed = subprocess.run(command, capture_output=True, text=True)
    if installed.returncode != 0:
        tail = ((installed.stdout or "") + "\n" + (installed.stderr or "")).strip()
        raise RuntimeError(tail[-2500:] or "pip could not install the Anima runtime.")
    ok, detail = _probe(python, env)
    if not ok:
        raise RuntimeError(detail or "AnimaAutoBlocks still did not import.")
    return python, env


def weight_path(kind: str) -> Path:
    return ROOT / WEIGHTS[kind][0]


def _download_file(url: str, dest: Path, minimum: int, status) -> None:
    part = dest.with_name(dest.name + ".part")
    if status:
        status(f"Downloading {dest.name} into the app folder")
    request = urllib.request.Request(url, headers={"User-Agent": "RedWright"})
    with urllib.request.urlopen(request, timeout=60) as response, part.open("wb") as handle:
        total = int(response.headers.get("Content-Length") or 0)
        done = 0
        reported = -1
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            handle.write(chunk)
            done += len(chunk)
            if status and total:
                percent = int(done * 100 / total)
                if percent >= reported + 10:
                    reported = percent
                    status(f"{dest.name} {percent}%")
    if not part.is_file() or part.stat().st_size < minimum:
        part.unlink(missing_ok=True)
        raise RuntimeError(f"{dest.name} did not finish downloading.")
    part.replace(dest)


def ensure_weights(status=None) -> tuple[Path, Path]:
    saved = []
    for kind in ("text", "vae"):
        name, url, minimum = WEIGHTS[kind]
        dest = ROOT / name
        if dest.is_file() and dest.stat().st_size >= minimum:
            saved.append(dest)
            continue
        if dest.is_file():
            dest.unlink()
        _download_file(url, dest, minimum, status)
        saved.append(dest)
    return saved[0], saved[1]


def _download_tokenizers(status) -> tuple[Path, Path]:
    for name in TOKEN_FILES:
        dest = TOKEN_ROOT / name
        if dest.is_file() and dest.stat().st_size > 0:
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        if status:
            status(f"Downloading {name}")
        request = urllib.request.Request(TOKEN_URL + name, headers={"User-Agent": "RedWright"})
        with urllib.request.urlopen(request, timeout=120) as response:
            dest.write_bytes(response.read())
    return TOKEN_ROOT / "tokenizer", TOKEN_ROOT / "t5_tokenizer"


def _block_count(state: dict) -> int:
    import re

    found = set()
    for key in state:
        match = re.search(r"blocks\.block(\d+)", key)
        if match:
            found.add(int(match.group(1)))
    return (max(found) + 1) if found else 28


def _load_split(model: Path, text: Path, vae: Path, shift: float, dtype, write=None):
    import torch
    from safetensors.torch import load_file

    sys.path.insert(0, str(TOOLS))
    from convert_anima_to_diffusers import (  # noqa: WPS433
        convert_qwen_image_vae,
        convert_text_conditioner,
        convert_text_encoder,
        split_anima_transformer_checkpoint,
    )
    from convert_cosmos_to_diffusers import TRANSFORMER_CONFIGS, convert_transformer
    from diffusers import AnimaAutoBlocks, FlowMatchEulerDiscreteScheduler
    from transformers import AutoTokenizer, T5TokenizerFast

    if write:
        write(f"Loading Anima model {model.name}")
    dit_state = load_file(str(model), device="cpu")
    transformer_state, conditioner_state = split_anima_transformer_checkpoint(dit_state)
    layers = _block_count(transformer_state)
    TRANSFORMER_CONFIGS["Cosmos-2.0-Diffusion-2B-Text2Image"]["num_layers"] = layers
    transformer = convert_transformer("Cosmos-2.0-Diffusion-2B-Text2Image", state_dict=transformer_state, weights_only=True)
    if write:
        write(f"Loading Qwen3 text encoder {text.name}")
    text_encoder = convert_text_encoder(load_file(str(text), device="cpu"))
    if write:
        write(f"Loading Qwen-Image VAE {vae.name}")
    vae_model = convert_qwen_image_vae(load_file(str(vae), device="cpu"))
    conditioner = convert_text_conditioner(conditioner_state)
    if write:
        write("Loading tokenizers")
    qwen_dir, t5_dir = _download_tokenizers(write)
    if write:
        write("Building the Anima pipeline")
    pipe = AnimaAutoBlocks().init_pipeline()
    pipe.update_components(
        text_encoder=text_encoder.to(dtype=dtype),
        tokenizer=AutoTokenizer.from_pretrained(str(qwen_dir)),
        t5_tokenizer=T5TokenizerFast.from_pretrained(str(t5_dir)),
        text_conditioner=conditioner.to(dtype=dtype),
        transformer=transformer.to(dtype=dtype),
        vae=vae_model.to(dtype=dtype),
        scheduler=FlowMatchEulerDiscreteScheduler(shift=shift),
    )
    return pipe


def _load_folder(folder: Path, shift: float, dtype):
    from diffusers import FlowMatchEulerDiscreteScheduler, ModularPipeline

    pipe = ModularPipeline.from_pretrained(str(folder))
    pipe.load_components(torch_dtype=dtype)
    pipe.scheduler = FlowMatchEulerDiscreteScheduler(shift=shift)
    return pipe


def _attach_loras(pipe, loras: list) -> None:
    names = []
    weights = []
    for index, item in enumerate(loras or []):
        path, weight = item[0], float(item[1])
        if not path:
            continue
        name = f"anima{index}"
        pipe.load_lora_weights(path, adapter_name=name)
        names.append(name)
        weights.append(weight)
    if names:
        pipe.set_adapters(names, adapter_weights=weights)


def draw(job: dict, write, on_preview=None) -> None:
    import torch
    from PIL import Image

    write("Loading the Anima model")
    model = Path(job["model"])
    shift = float(job.get("shift") or 3)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.bfloat16 if device == "cuda" and torch.cuda.is_bf16_supported() else torch.float16
    write(f"Device {device}, precision {str(dtype).replace('torch.', '')}")
    if model.is_dir():
        write(f"Loading diffusers folder {model.name}")
        pipe = _load_folder(model, shift, dtype)
    else:
        text = Path(job.get("text") or "")
        vae = Path(job.get("vae") or "")
        if not text.is_file() or not vae.is_file():
            raise RuntimeError("Anima needs the Qwen3 0.6B text encoder and the Qwen-Image VAE, or a diffusers folder.")
        pipe = _load_split(model, text, vae, shift, dtype, write)
    loras = job.get("loras") or []
    if loras:
        write(f"Loading {len(loras)} Anima LoRA{'s' if len(loras) != 1 else ''}")
    _attach_loras(pipe, loras)
    write("Moving the model onto the GPU")
    try:
        pipe.enable_model_cpu_offload()
    except Exception:
        pipe.to(device)
    steps = int(job["steps"])
    seed = job.get("seed")
    generator = None
    if seed is not None:
        generator = torch.Generator(device=device).manual_seed(int(seed))
    width = int(job["width"])
    height = int(job["height"])
    write(f"Encoding the prompt, {width}x{height}, {steps} steps")

    def on_step(_pipe, step, _timestep, callback_kwargs):
        write(f"Step {int(step) + 1} / {steps}")
        return callback_kwargs

    kwargs = {
        "prompt": job.get("prompt") or "",
        "negative_prompt": job.get("negative") or "",
        "num_inference_steps": steps,
        "guidance_scale": float(job.get("cfg") or 4),
        "height": height,
        "width": width,
        "max_sequence_length": int(job.get("max_length") or 512),
        "generator": generator,
        "callback_on_step_end": on_step,
    }
    source = str(job.get("init_image") or "")
    if source and Path(source).is_file():
        write(f"Reading the source picture at denoise {float(job.get('init_denoise') or 0.6):.2f}")
        kwargs["image"] = Image.open(source).convert("RGB")
        kwargs["strength"] = float(job.get("init_denoise") or 0.6)
    write(f"Step 0 / {steps}")
    try:
        result = pipe(**{key: value for key, value in kwargs.items() if value is not None})
    except TypeError as exc:
        if "callback_on_step_end" not in str(exc):
            raise
        write("Sampling without a step callback")
        kwargs.pop("callback_on_step_end", None)
        result = pipe(**{key: value for key, value in kwargs.items() if value is not None})
    images = getattr(result, "images", None)
    if images is None and isinstance(result, dict):
        images = result.get("images")
    if not images:
        raise RuntimeError("Anima did not return a picture.")
    write("Decoding and saving the picture")
    image = images[0]
    Path(job["out"]).parent.mkdir(parents=True, exist_ok=True)
    image.save(job["out"])
    if on_preview is not None:
        on_preview(image, "Final")
    write("done")


def _buckets(base: int) -> list[tuple[int, int]]:
    step = 16
    base = max(step, int(base) - int(base) % step)
    area = base * base
    limit = base * 2
    found: set[tuple[int, int]] = set()
    width = step
    while width <= limit:
        height = int(round(area / width / step)) * step
        height = max(step, min(limit, height))
        found.add((width, height))
        found.add((height, width))
        width += step
    return sorted(found)


def _fit_bucket(image, buckets: list[tuple[int, int]]):
    from PIL import Image

    width, height = image.size
    aspect = width / max(height, 1)
    bucket_w, bucket_h = min(buckets, key=lambda item: abs((item[0] / item[1]) - aspect))
    scale = max(bucket_w / width, bucket_h / height)
    resized_w = max(bucket_w, int(round(width * scale)))
    resized_h = max(bucket_h, int(round(height * scale)))
    image = image.resize((resized_w, resized_h), Image.Resampling.LANCZOS)
    left = max(0, (resized_w - bucket_w) // 2)
    top = max(0, (resized_h - bucket_h) // 2)
    return image.crop((left, top, left + bucket_w, top + bucket_h)), bucket_w, bucket_h


def _caption(subject: str, trigger: str, caption: str, stem: str) -> str:
    trigger = trigger.strip()
    caption = caption.strip()
    if subject == "style":
        if trigger and trigger.lower() not in caption.lower():
            caption = f"{caption}, {trigger}".strip(", ") if caption else trigger
        return caption or stem
    if trigger and trigger.lower() not in caption.lower():
        caption = f"{trigger}, {caption}".strip(", ") if caption else trigger
    return caption or trigger or stem


def _encode_text(pipe, caption: str, device, dtype):
    import torch

    tokens = pipe.tokenizer(caption, padding="longest", max_length=512, truncation=True, return_tensors="pt")
    ids = tokens.input_ids.to(device)
    mask = tokens.attention_mask.to(device)
    hidden = pipe.text_encoder(input_ids=ids, attention_mask=mask).last_hidden_state
    hidden = hidden.to(dtype=dtype) * mask.to(dtype=hidden.dtype).unsqueeze(-1)
    t5 = pipe.t5_tokenizer(caption, padding="longest", max_length=512, truncation=True, return_tensors="pt")
    embeds = pipe.text_conditioner(
        source_hidden_states=hidden.to(dtype=pipe.text_conditioner.dtype),
        target_input_ids=t5.input_ids.to(device),
        target_attention_mask=t5.attention_mask.to(device),
        source_attention_mask=mask,
    )
    if isinstance(embeds, tuple):
        embeds = embeds[0]
    if not torch.is_tensor(embeds):
        embeds = getattr(embeds, "last_hidden_state", None) or embeds[0]
    return embeds.detach().to(dtype=dtype).cpu()


def _encode_pixels(vae, pixel, device, fp32: bool):
    import torch

    dtype = torch.float32 if fp32 else next(vae.parameters()).dtype
    image = pixel.to(device=device, dtype=dtype).unsqueeze(2)
    encoded = vae.encode(image)
    latents = encoded.latent_dist.mode() if hasattr(encoded, "latent_dist") else encoded.latents
    if latents.dim() == 4:
        latents = latents.unsqueeze(2)
    channels = latents.shape[1]
    mean = torch.tensor(vae.config.latents_mean, device=latents.device, dtype=latents.dtype).view(1, channels, 1, 1, 1)
    std = torch.tensor(vae.config.latents_std, device=latents.device, dtype=latents.dtype).view(1, channels, 1, 1, 1)
    return ((latents - mean) / std).detach().cpu()


def _save_anima_lora(path: Path, transformer, rank: int, alpha: int, trigger: str) -> None:
    import torch
    from peft.utils import get_peft_model_state_dict
    from safetensors.torch import save_file

    state = get_peft_model_state_dict(transformer)
    tensors = {}
    for key, value in state.items():
        if not torch.isfinite(value).all():
            raise RuntimeError("Training produced invalid LoRA weights. Lower the learning rate and train again.")
        name = key.replace("base_model.model.", "").replace(".default.", ".")
        tensors["transformer." + name] = value.detach().float().cpu().contiguous()
    if not any(key.endswith("lora_B.weight") or key.endswith("lora_B.default.weight") for key in tensors):
        raise RuntimeError("Nothing was trained.")
    path.parent.mkdir(parents=True, exist_ok=True)
    save_file(
        tensors,
        str(path),
        metadata={
            "format": "pt",
            "modelspec.architecture": "Anima LoRA",
            "modelspec.trigger_phrase": trigger.strip(),
            "ss_network_dim": str(rank),
            "ss_network_alpha": str(alpha),
        },
    )


def train(job: dict, write) -> None:
    import gc
    import random

    import numpy as np
    import torch
    import torch.nn.functional as F
    from PIL import Image
    from peft import LoraConfig

    folder = Path(job["folder"])
    images = [
        path
        for path in sorted(folder.iterdir())
        if path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
    ]
    if not images:
        raise RuntimeError("That folder has no pictures.")
    rank = int(job["rank"])
    alpha = int(job.get("alpha") or rank)
    steps = int(job["steps"])
    size = max(256, int(job["resolution"]) - int(job["resolution"]) % 16)
    trigger = (job.get("trigger") or "").strip()
    subject = job.get("subject") if job.get("subject") in {"character", "style", "concept"} else "character"
    use_buckets = bool(job.get("buckets", True))
    checkpoint = bool(job.get("checkpoint", True))
    cache_latents = bool(job.get("cache_latents", True))
    fp32_vae = bool(job.get("fp32_vae", True))
    shift = float(job.get("shift") or 3)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.bfloat16 if device == "cuda" and torch.cuda.is_bf16_supported() else torch.float16
    model = Path(job["model"])
    write(f"Loading {model.name}")
    if model.is_dir():
        pipe = _load_folder(model, shift, dtype)
    else:
        text = Path(job.get("text") or "")
        vae = Path(job.get("vae") or "")
        if not text.is_file() or not vae.is_file():
            raise RuntimeError("Anima training needs the Qwen3 text encoder and the Qwen-Image VAE.")
        pipe = _load_split(model, text, vae, shift, dtype, write)
    pipe.vae.to(device=device, dtype=torch.float32 if fp32_vae else dtype)
    pipe.text_encoder.to(device)
    pipe.text_conditioner.to(device)
    buckets = _buckets(size) if use_buckets else [(size, size)]
    write(
        f"{subject} · rank {rank} · alpha {alpha} · shift {shift:g} · "
        + ("aspect buckets" if use_buckets else "square crop")
        + (" · float32 VAE" if fp32_vae else "")
    )
    pairs = []
    used = set()
    for path in images:
        caption_file = path.with_suffix(".txt")
        caption = caption_file.read_text(encoding="utf-8").strip() if caption_file.is_file() else ""
        caption = _caption(subject, trigger, caption, path.stem)
        image = Image.open(path).convert("RGB")
        if use_buckets:
            image, bucket_w, bucket_h = _fit_bucket(image, buckets)
        else:
            width, height = image.size
            side = min(width, height)
            left = (width - side) // 2
            top = (height - side) // 2
            image = image.crop((left, top, left + side, top + side)).resize((size, size), Image.Resampling.LANCZOS)
            bucket_w, bucket_h = size, size
        used.add((bucket_w, bucket_h))
        pixel = torch.from_numpy(np.asarray(image, dtype="float32")).permute(2, 0, 1).unsqueeze(0) / 127.5 - 1
        embeds = _encode_text(pipe, caption, device, dtype)
        if cache_latents:
            with torch.no_grad():
                latent = _encode_pixels(pipe.vae, pixel, device, fp32_vae)
            stored = latent
        else:
            stored = pixel.cpu()
        pairs.append((stored, embeds, bucket_w, bucket_h, cache_latents))
        write(f"Prepared {path.name} at {bucket_w}×{bucket_h}")
    pipe.text_encoder.to("cpu")
    pipe.text_conditioner.to("cpu")
    if cache_latents:
        pipe.vae.to("cpu")
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    transformer = pipe.transformer
    transformer.to(device)
    if checkpoint and hasattr(transformer, "enable_gradient_checkpointing"):
        transformer.enable_gradient_checkpointing()
    transformer.add_adapter(LoraConfig(r=rank, lora_alpha=alpha, target_modules=["to_q", "to_k", "to_v", "to_out.0"]))
    transformer.train()
    trainable = [param for param in transformer.parameters() if param.requires_grad]
    if not trainable:
        raise RuntimeError("No Anima attention layers were found to train.")
    masters = [param.detach().float().clone().requires_grad_(True) for param in trainable]
    opt = torch.optim.AdamW(masters, lr=float(job["lr"]), foreach=False)
    weight_dtype = next(param.dtype for param in transformer.parameters() if not param.requires_grad)
    write(f"Training {len(pairs)} pictures in {len(used)} bucket sizes")
    skipped = 0
    for step in range(steps):
        stored, embeds, bucket_w, bucket_h, cached = random.choice(pairs)
        embeds = embeds.to(device=device, dtype=weight_dtype)
        if cached:
            latent = stored.to(device=device, dtype=torch.float32)
        else:
            with torch.no_grad():
                latent = _encode_pixels(pipe.vae, stored, device, fp32_vae).to(device=device, dtype=torch.float32)
        noise = torch.randn_like(latent)
        draw_u = torch.rand((), device=device)
        sigma = (draw_u * shift) / (1 + (shift - 1) * draw_u)
        sigma = sigma.clamp(1e-4, 1 - 1e-4)
        noisy = ((1 - sigma) * latent + sigma * noise).to(dtype=weight_dtype)
        target = noise - latent
        pad = noisy.new_zeros(1, 1, bucket_h, bucket_w)
        pred = transformer(
            hidden_states=noisy,
            timestep=sigma.expand(noisy.shape[0]).to(dtype=weight_dtype),
            encoder_hidden_states=embeds,
            padding_mask=pad,
            return_dict=False,
        )[0]
        if not torch.isfinite(pred).all():
            opt.zero_grad(set_to_none=True)
            skipped += 1
            write(f"Step {step + 1} skipped because the picture became invalid")
            continue
        loss = F.mse_loss(pred.float(), target)
        if not torch.isfinite(loss):
            opt.zero_grad(set_to_none=True)
            skipped += 1
            continue
        loss.backward()
        grads_ok = True
        for param, master in zip(trainable, masters):
            grad = None if param.grad is None else param.grad.detach().float()
            param.grad = None
            if grad is None or not torch.isfinite(grad).all():
                grads_ok = False
                master.grad = None
                continue
            master.grad = grad
        if not grads_ok:
            opt.zero_grad(set_to_none=True)
            skipped += 1
            continue
        torch.nn.utils.clip_grad_norm_(masters, 1.0)
        opt.step()
        opt.zero_grad(set_to_none=True)
        with torch.no_grad():
            for param, master in zip(trainable, masters):
                param.copy_(master.to(dtype=param.dtype))
        if step % 5 == 0 or step + 1 == steps:
            write(f"Step {step + 1}/{steps}  loss {loss.item():.4f}")
    if skipped > steps // 2:
        raise RuntimeError("Training kept producing invalid numbers. Lower the learning rate and try again.")
    _save_anima_lora(Path(job["out"]), transformer, rank, alpha, trigger)
    transformer.to("cpu")
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    write(f"Saved {job['out']}")
