"""Cardwright, as a Python generator beside RedGen.

Writes Marinara / SillyTavern Character Card V2 JSON through KoboldCPP,
packs that JSON into a PNG, and can ask NovelAI for a portrait.
Nothing here needs a GPU. RedGen still draws locally on the Generate tab.
"""

from __future__ import annotations

import base64
import json
import random
import re
import sys
import urllib.error
import urllib.request
import uuid
import zipfile
from io import BytesIO
from pathlib import Path

NOVEL_URL = "https://image.novelai.net/ai/generate-image"
DEFAULT_KOBOLD = "http://127.0.0.1:5001/v1"
DEFAULT_NOVEL_MODEL = "nai-diffusion-5-full"
NOVEL_MODELS = (
    ("V5 Full", "nai-diffusion-5-full"),
    ("V5 Curated", "nai-diffusion-5-curated"),
    ("V4.5 Full", "nai-diffusion-4-5-full"),
    ("V4.5 Curated", "nai-diffusion-4-5-curated"),
)
NOVEL_SETTINGS = {
    "novel_token": "",
    "novel_model": DEFAULT_NOVEL_MODEL,
    "novel_seed": "-1",
    "novel_style": "Anime",
    "novel_danbooru": True,
    "novel_steps": 25,
    "novel_guidance": 6.8,
    "novel_rescale": 0.0,
    "novel_uc": 2,
    "novel_prefix": "",
    "novel_negative": "",
    "novel_sampler": "k_euler_ancestral",
    "novel_schedule": "karras",
    "novel_auto": False,
    "novel_width": 1024,
    "novel_height": 1024,
    "novel_strength": 0.65,
    "novel_fidelity": 0.65,
    "novel_plate": "",
}

CARD_SYSTEM = """You write character cards for Marinara Engine, which reads SillyTavern Character Card V2.
Return one JSON object and nothing else. No markdown fences. No commentary.
Use {{char}} for the character and {{user}} for the person they meet. Do not invent a name for {{user}}.
Write concrete facts, not adjective piles. first_mes is spoken in character, with actions in asterisks.
mes_example contains two or three exchanges, each block starting with <START>.
summary is one sentence for a library list and is not roleplay prose.
tags is an array of 3 to 6 short labels.
talkativeness is an integer from 0 to 100.
Leave system_prompt and post_history_instructions as empty strings unless the concept demands a hard rule."""

PICTURE_NOTE = """Reference images are attached. They are the character, not a suggestion.
appearance must match what is visible: face, body, clothing, colors, and setting cues.
Do not invent a conflicting look. You may name them and write personality if the concept does not."""

PERSONA_SYSTEM = """You write a Marinara persona: the character card that stands for the human in a chat, not the character they talk to.
Return one JSON object and nothing else. No markdown fences. No commentary.
Use {{user}} for this persona and {{char}} for the other character. Do not invent a name for {{char}}.
Write concrete facts. first_mes must be an empty string. alternate_greetings must be an empty array.
mes_example shows how {{user}} speaks, two short exchanges, each block starting with <START>.
summary is one sentence for a library list.
tags is an array of 3 to 6 short labels.
Leave system_prompt and post_history_instructions as empty strings."""

SCHEMA_HINT = """JSON keys:
{
  "name": "",
  "summary": "",
  "description": "",
  "personality": "",
  "scenario": "",
  "first_mes": "",
  "mes_example": "",
  "creator_notes": "",
  "backstory": "",
  "appearance": "",
  "tags": [],
  "alternate_greetings": [],
  "talkativeness": 50,
  "system_prompt": "",
  "post_history_instructions": ""
}"""

FIELD_GUIDES = {
    "name": "A fitting proper name only.",
    "summary": "One sentence for a library preview. Not roleplay prose.",
    "description": "120 to 220 words. Who they are. Use {{char}} and {{user}}.",
    "personality": "How they behave and speak. Concrete habits.",
    "backstory": "Origin, relationships, facts that stay true.",
    "appearance": "Face, build, clothes, and visual detail. Comma-separated tags are fine.",
    "scenario": "The default opening situation. Use {{char}} and {{user}}.",
    "first_mes": "80 to 180 words, in character, actions in asterisks. End on something {{user}} can answer.",
    "mes_example": "Two exchanges. Each begins with <START> on its own line.",
    "creator_notes": "A short note for the human, including tone or content if it matters.",
    "system_prompt": "Only if a hard rule is required. Otherwise empty string.",
    "post_history_instructions": "Only if a hard rule must sit after history. Otherwise empty string.",
    "creator": "Keep Cardwright unless the concept names an author.",
    "character_version": "A short version string, usually 1.0.",
}

STRING_FIELDS = (
    "name",
    "summary",
    "description",
    "personality",
    "scenario",
    "first_mes",
    "mes_example",
    "creator_notes",
    "system_prompt",
    "post_history_instructions",
    "creator",
    "character_version",
    "backstory",
    "appearance",
    "aliases",
    "long_memory",
)


def blank_card() -> dict:
    return {
        "name": "",
        "summary": "",
        "description": "",
        "personality": "",
        "scenario": "",
        "first_mes": "",
        "mes_example": "",
        "creator_notes": "",
        "system_prompt": "",
        "post_history_instructions": "",
        "tags": [],
        "creator": "Cardwright",
        "character_version": "1.0",
        "alternate_greetings": [],
        "backstory": "",
        "appearance": "",
        "talkativeness": 50,
        "aliases": "",
        "long_memory": "",
        "lorebook_id": "",
    }


def kobold_root(base: str) -> str:
    text = (base or DEFAULT_KOBOLD).strip().rstrip("/")
    if not text.startswith("http"):
        text = "http://" + text
    if not re.search(r"/v1$", text, re.I):
        text += "/v1"
    return text


def _request(url: str, payload: dict | None, headers: dict, timeout: int) -> tuple[int, bytes, str]:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers, method="GET" if payload is None else "POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return response.status, response.read(), response.headers.get("Content-Type", "")
    except urllib.error.HTTPError as exc:
        body = exc.read()
        raise RuntimeError(_http_error(exc.code, body)) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not reach KoboldCPP ({exc.reason}).") from exc


def _http_error(code: int, body: bytes) -> str:
    text = body.decode("utf-8", errors="replace")
    try:
        message = json.loads(text).get("message")
        if isinstance(message, str) and message.strip():
            return message.strip()
    except json.JSONDecodeError:
        pass
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300] or f"The model returned HTTP {code}."


def _message_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and isinstance(item.get("text"), str):
                parts.append(item["text"])
        return "".join(parts)
    return ""


def kobold_chat(base: str, key: str, messages: list[dict], *, model: str = "koboldcpp", temperature: float = 0.8, max_tokens: int = 2200) -> str:
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if key.strip():
        headers["Authorization"] = f"Bearer {key.strip()}"
    url = f"{kobold_root(base)}/chat/completions"
    _status, body, _kind = _request(
        url,
        {
            "model": model.strip() or "koboldcpp",
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        },
        headers,
        180,
    )
    try:
        payload = json.loads(body.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise RuntimeError("KoboldCPP did not return JSON.") from exc
    content = _message_text(((payload.get("choices") or [{}])[0].get("message") or {}).get("content"))
    if content.strip():
        return content
    raise RuntimeError("KoboldCPP returned an empty reply.")


def kobold_ping(base: str, key: str) -> str:
    headers = {"Accept": "application/json"}
    if key.strip():
        headers["Authorization"] = f"Bearer {key.strip()}"
    url = f"{kobold_root(base)}/models"
    try:
        _status, body, _kind = _request(url, None, headers, 8)
    except RuntimeError as exc:
        if "KoboldCPP" in str(exc):
            raise RuntimeError(str(exc).replace("KoboldCPP", "KoboldCPP")) from exc
        raise
    try:
        data = json.loads(body.decode("utf-8"))
    except json.JSONDecodeError:
        return "Connected to KoboldCPP."
    rows = data.get("data") if isinstance(data, dict) else None
    if isinstance(rows, list) and rows:
        name = rows[0].get("id") if isinstance(rows[0], dict) else None
        if name:
            return f"Connected. Model: {name}"
    return "Connected to KoboldCPP."


def _json_object(text: str) -> dict:
    raw = text.strip()
    fenced = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw, re.I)
    if fenced:
        raw = fenced.group(1).strip()
    start = raw.find("{")
    end = raw.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("The model did not return a JSON object.")
    value = json.loads(raw[start : end + 1])
    if not isinstance(value, dict):
        raise ValueError("The model did not return a JSON object.")
    return value


def _as_strings(value) -> list[str]:
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list):
        return []
    return [item.strip() for item in value if isinstance(item, str) and item.strip()]


def normalize_card(raw: dict, *, persona: bool = False) -> dict:
    card = blank_card()
    source = raw.get("data") if isinstance(raw.get("data"), dict) else raw
    extensions = source.get("extensions") if isinstance(source.get("extensions"), dict) else {}
    for key in STRING_FIELDS:
        incoming = source.get(key)
        if not isinstance(incoming, str) and key in ("backstory", "appearance"):
            incoming = extensions.get(key)
        if isinstance(incoming, str):
            card[key] = incoming
    tags = _as_strings(source.get("tags"))
    if tags:
        card["tags"] = tags[:8]
    greetings = _as_strings(source.get("alternate_greetings"))
    if greetings:
        card["alternate_greetings"] = greetings
    talk = extensions.get("talkativeness", source.get("talkativeness"))
    if isinstance(talk, (int, float)) and not isinstance(talk, bool):
        card["talkativeness"] = max(0, min(100, int(round(talk))))
    aliases = source.get("aliases") or extensions.get("aliases") or ""
    if isinstance(aliases, str):
        card["aliases"] = aliases
    memory = extensions.get("long_memory") or extensions.get("longMemory") or source.get("long_memory") or ""
    if isinstance(memory, str):
        card["long_memory"] = memory
    lore = extensions.get("cardwright_lorebook") or source.get("lorebook_id") or ""
    if isinstance(lore, str):
        card["lorebook_id"] = lore
    if not card["creator"].strip():
        card["creator"] = "Cardwright"
    if not card["character_version"].strip():
        card["character_version"] = "1.0"
    if persona:
        card["first_mes"] = ""
        card["alternate_greetings"] = []
    return card


def fill_blanks(current: dict, incoming: dict) -> dict:
    card = normalize_card(current)
    fresh = normalize_card(incoming)
    for key in STRING_FIELDS:
        if not str(card[key]).strip() and str(fresh[key]).strip():
            card[key] = fresh[key]
    if not card["tags"] and fresh["tags"]:
        card["tags"] = list(fresh["tags"])
    if not card["alternate_greetings"] and fresh["alternate_greetings"]:
        card["alternate_greetings"] = list(fresh["alternate_greetings"])
    return card


def to_v2(card: dict) -> dict:
    card = normalize_card(card)
    return {
        "spec": "chara_card_v2",
        "spec_version": "2.0",
        "data": {
            "name": card["name"].strip() or "Unnamed",
            "summary": card["summary"],
            "description": card["description"],
            "personality": card["personality"],
            "scenario": card["scenario"],
            "first_mes": card["first_mes"],
            "mes_example": card["mes_example"],
            "creator_notes": card["creator_notes"],
            "system_prompt": card["system_prompt"],
            "post_history_instructions": card["post_history_instructions"],
            "tags": list(card["tags"]),
            "creator": card["creator"].strip() or "Cardwright",
            "character_version": card["character_version"].strip() or "1.0",
            "alternate_greetings": [item for item in card["alternate_greetings"] if item.strip()],
            "character_book": None,
            "extensions": {
                "talkativeness": card["talkativeness"],
                "fav": False,
                "backstory": card["backstory"],
                "appearance": card["appearance"],
                "aliases": card["aliases"],
                "long_memory": card["long_memory"],
                "cardwright_lorebook": card["lorebook_id"],
            },
        },
    }


def _write(base: str, key: str, concept: str, *, persona: bool, model: str, temperature: float, max_tokens: int) -> dict:
    text = concept.strip()
    if len(text) < 8:
        kind = "persona" if persona else "character"
        raise RuntimeError(f"Describe the {kind} in a sentence or two, or add a reference picture.")
    system = PERSONA_SYSTEM if persona else CARD_SYSTEM
    user = ("Write a persona from this concept:\n" if persona else "Write a full character card from this concept:\n") + text + "\n\n" + SCHEMA_HINT
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]
    reply = kobold_chat(base, key, messages, model=model, temperature=temperature, max_tokens=max_tokens)
    try:
        return normalize_card(_json_object(reply), persona=persona)
    except (ValueError, json.JSONDecodeError):
        messages.append({"role": "assistant", "content": reply})
        messages.append({"role": "user", "content": "That was not valid JSON. Reply again with only the JSON object, no fences."})
        reply = kobold_chat(base, key, messages, model=model, temperature=temperature, max_tokens=max_tokens)
        try:
            return normalize_card(_json_object(reply), persona=persona)
        except (ValueError, json.JSONDecodeError) as exc:
            raise RuntimeError("Could not read the card.") from exc


def write_card(base: str, key: str, concept: str, *, model: str = "koboldcpp", temperature: float = 0.8, max_tokens: int = 2200) -> dict:
    return _write(base, key, concept, persona=False, model=model, temperature=temperature, max_tokens=max_tokens)


def write_persona(base: str, key: str, concept: str, *, model: str = "koboldcpp", temperature: float = 0.8, max_tokens: int = 2200) -> dict:
    return _write(base, key, concept, persona=True, model=model, temperature=temperature, max_tokens=max_tokens)


def rewrite_field(base: str, key: str, concept: str, card: dict, field: str, *, model: str = "koboldcpp", temperature: float = 0.8) -> str:
    prompt = concept.strip()
    if len(prompt) < 8:
        raise RuntimeError("Put the prompt in Concept first.")
    if field not in FIELD_GUIDES:
        raise RuntimeError(f"Unknown field: {field}")
    guide = FIELD_GUIDES[field]
    current = normalize_card(card)
    others = {name: current[name] for name in STRING_FIELDS if name != field and str(current.get(name) or "").strip()}
    user = (
        f'Write only the "{field}" field from the concept. Do not write any other field.\n'
        f"Guide: {guide}\n"
        f"Concept:\n{prompt}\n\n"
        "Other fields already filled, for consistency. Do not repeat them:\n"
        f"{json.dumps(others, ensure_ascii=False)}\n\n"
        "Return only the field text. No label and no markdown."
    )
    reply = kobold_chat(
        base,
        key,
        [
            {"role": "system", "content": "You fill one character-card field from the concept. Return only that field's text."},
            {"role": "user", "content": user},
        ],
        model=model,
        temperature=temperature,
        max_tokens=800,
    )
    text = reply.strip()
    try:
        payload = _json_object(text)
    except (ValueError, json.JSONDecodeError):
        payload = None
    if isinstance(payload, dict):
        value = payload.get("value", payload.get(field))
        if isinstance(value, str) and value.strip():
            return value.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:\w+)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    return text.strip()


def novel_prompt(card: dict) -> str:
    card = normalize_card(card)
    parts = [card["appearance"], card["name"], card["scenario"]]
    tags = []
    for part in parts:
        for piece in re.split(r"[,;\n]+", part):
            piece = piece.strip()
            if piece and piece not in tags:
                tags.append(piece)
    return ", ".join(tags)


def character_count(prompt: str) -> int | None:
    found = False
    total = 0
    for match in re.finditer(r"(\d+)\s*(?:girl|boy|person|people|character)s?", prompt, re.I):
        found = True
        total += int(match.group(1))
    return total if found else None


def novel_size(prompt: str, width: int, height: int, auto: bool) -> tuple[int, int]:
    if not auto:
        return width, height
    count = character_count(prompt)
    if count is None:
        return width, height
    if count <= 1:
        return 832, 1216
    if count == 2:
        return 1024, 1024
    return 1216, 832


def novel_body(prompt: str, settings: dict) -> dict:
    model = str(settings.get("model") or DEFAULT_NOVEL_MODEL).strip() or DEFAULT_NOVEL_MODEL
    prefix = str(settings.get("prefix") or "").strip()
    negative_prefix = str(settings.get("negative") or "").strip()
    text = ", ".join(part for part in (prefix, prompt.strip()) if part)
    negative = ", ".join(part for part in (negative_prefix, str(settings.get("extra_negative") or "").strip()) if part)
    width, height = novel_size(text, int(settings.get("width") or 1024), int(settings.get("height") or 1024), bool(settings.get("auto")))
    width = max(64, min(1792, width - width % 64))
    height = max(64, min(1792, height - height % 64))
    seed = int(settings.get("seed") if settings.get("seed") is not None else -1)
    used = random.randrange(0, 2**32) if seed < 0 else seed & 0xFFFFFFFF
    version = 4 if "diffusion-5" in model else 3
    parameters = {
        "params_version": version,
        "width": width,
        "height": height,
        "scale": float(settings.get("guidance") if settings.get("guidance") is not None else 6.8),
        "sampler": str(settings.get("sampler") or "k_euler_ancestral"),
        "steps": max(1, min(50, int(settings.get("steps") or 25))),
        "seed": used,
        "n_samples": 1,
        "negative_prompt": negative,
        "qualityToggle": not bool(prefix),
        "ucPreset": int(settings.get("uc") if settings.get("uc") is not None else 2),
        "cfg_rescale": float(settings.get("rescale") or 0),
        "noise_schedule": str(settings.get("schedule") or "karras"),
        "legacy": False,
        "v4_prompt": {"caption": {"base_caption": text, "char_captions": []}, "use_coords": False, "use_order": True},
        "v4_negative_prompt": {"caption": {"base_caption": negative, "char_captions": []}, "legacy_uc": False},
    }
    plate = str(settings.get("plate") or "").strip()
    if plate and "4-5" in model and Path(plate).is_file():
        encoded = base64.b64encode(Path(plate).read_bytes()).decode("ascii")
        parameters["reference_image_multiple"] = [encoded]
        parameters["reference_strength_multiple"] = [float(settings.get("strength") if settings.get("strength") is not None else 0.65)]
        parameters["reference_information_extracted_multiple"] = [float(settings.get("fidelity") if settings.get("fidelity") is not None else 0.65)]
    return {
        "input": text,
        "model": model,
        "action": "generate",
        "parameters": parameters,
    }


def novel_ping(token: str) -> str:
    token = token.strip()
    if not token:
        raise RuntimeError("Add your NovelAI persistent token.")
    req = urllib.request.Request(
        "https://api.novelai.net/user/subscription",
        headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise RuntimeError(_http_error(exc.code, exc.read()).replace("KoboldCPP", "NovelAI")) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not reach NovelAI ({exc.reason}).") from exc
    tier = payload.get("tier") if isinstance(payload, dict) else None
    return f"NovelAI accepted the token.{f' Tier {tier}.' if tier is not None else ''}"


def novel_generate(token: str, prompt: str, settings: dict | None = None, **legacy) -> "object":
    from PIL import Image

    token = token.strip()
    if not token:
        raise RuntimeError("Add your NovelAI persistent token.")
    if not prompt.strip() and not str((settings or {}).get("prefix") or legacy.get("negative") or "").strip():
        raise RuntimeError("Write an appearance, or a prompt, before drawing.")
    setup = {
        "model": legacy.get("model") or DEFAULT_NOVEL_MODEL,
        "width": legacy.get("width") or 1024,
        "height": legacy.get("height") or 1024,
        "steps": legacy.get("steps") or 25,
        "guidance": legacy.get("guidance") if legacy.get("guidance") is not None else 6.8,
        "seed": legacy.get("seed") if legacy.get("seed") is not None else -1,
        "extra_negative": legacy.get("negative") or "",
        "sampler": "k_euler_ancestral",
        "schedule": "karras",
        "uc": 2,
        "rescale": 0,
    }
    if settings:
        setup.update(settings)
    body = novel_body(prompt, setup)
    req = urllib.request.Request(
        NOVEL_URL,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/zip, image/png, application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=180) as response:
            payload = response.read()
            kind = response.headers.get("Content-Type", "")
    except urllib.error.HTTPError as exc:
        raise RuntimeError(_http_error(exc.code, exc.read()).replace("KoboldCPP", "NovelAI")) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not reach NovelAI ({exc.reason}).") from exc
    return _image_from_novel(payload, kind)


def _image_from_novel(payload: bytes, kind: str):
    from PIL import Image

    if payload[:8] == b"\x89PNG\r\n\x1a\n":
        return Image.open(BytesIO(payload)).convert("RGB")
    if payload[:2] == b"PK" or "zip" in kind:
        with zipfile.ZipFile(BytesIO(payload)) as bundle:
            names = [name for name in bundle.namelist() if name.lower().endswith(".png")]
            if not names:
                raise RuntimeError("NovelAI returned no picture.")
            return Image.open(BytesIO(bundle.read(names[0]))).convert("RGB")
    try:
        message = json.loads(payload.decode("utf-8")).get("message")
    except (UnicodeDecodeError, json.JSONDecodeError):
        message = None
    raise RuntimeError(message or "NovelAI did not return a picture.")


def text_plate(card: dict):
    from PIL import Image, ImageDraw

    card = normalize_card(card)
    image = Image.new("RGB", (832, 1216), "#1c1a17")
    draw = ImageDraw.Draw(image)
    draw.rectangle((36, 36, 796, 1180), outline="#e23d2b", width=3)
    name = card["name"].strip() or "Unnamed"
    summary = card["summary"].strip() or "No summary yet."
    draw.text((64, 72), name[:48], fill="#f4efe6")
    y = 130
    for word in _wrap(summary, 42):
        draw.text((64, y), word, fill="#a39b90")
        y += 22
        if y > 1100:
            break
    draw.text((64, 1140), "RedWright  ·  text plate, not a portrait", fill="#e23d2b")
    return image


def _wrap(text: str, width: int) -> list[str]:
    lines = []
    for paragraph in text.splitlines() or [""]:
        words = paragraph.split()
        line = ""
        for word in words:
            trial = word if not line else f"{line} {word}"
            if len(trial) > width:
                if line:
                    lines.append(line)
                line = word
            else:
                line = trial
        lines.append(line)
    return lines or [""]


def pack_png(image, card: dict) -> bytes:
    from PIL import PngImagePlugin

    info = PngImagePlugin.PngInfo()
    encoded = base64.b64encode(json.dumps(to_v2(card), ensure_ascii=False).encode("utf-8")).decode("ascii")
    info.add_text("chara", encoded)
    buffer = BytesIO()
    image.convert("RGB").save(buffer, format="PNG", pnginfo=info)
    return buffer.getvalue()


def read_png_card(path: Path) -> dict | None:
    from PIL import Image

    with Image.open(path) as image:
        raw = image.info.get("chara") or image.info.get("ccv3")
    if not isinstance(raw, str) or not raw.strip():
        return None
    try:
        decoded = base64.b64decode(raw)
        return normalize_card(json.loads(decoded.decode("utf-8")))
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return None


def slug(name: str) -> str:
    text = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return text or "character"


def settings_path() -> Path:
    if sys.platform == "win32":
        root = Path.home() / "AppData" / "Roaming" / "RedGen"
    else:
        root = Path.home() / ".redgen"
    return root / "cards.json"


def load_settings() -> dict:
    base = {
        "kobold": DEFAULT_KOBOLD,
        "key": "",
        "model": "koboldcpp",
        "temperature": 0.8,
        "max_tokens": 2200,
    }
    base.update(NOVEL_SETTINGS)
    path = settings_path()
    if not path.is_file():
        return base
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return base
    if isinstance(data, dict):
        for key in base:
            if key in data:
                base[key] = data[key]
    return base


def save_settings(data: dict) -> None:
    path = settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def library_path() -> Path:
    return settings_path().parent / "card-library.json"


def load_library() -> list[dict]:
    path = library_path()
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    rows = data.get("cards") if isinstance(data, dict) else data
    if not isinstance(rows, list):
        return []
    kept = []
    for row in rows:
        if isinstance(row, dict) and isinstance(row.get("id"), str) and isinstance(row.get("card"), dict):
            kept.append(row)
    return kept


def merge_library(entries: list[dict], entry: dict, limit: int = 200) -> list[dict]:
    items = [item for item in entries if item.get("id") != entry.get("id")]
    items.insert(0, entry)
    return items[:limit]


def write_library(entries: list[dict]) -> None:
    path = library_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"cards": entries}, indent=2, ensure_ascii=False), encoding="utf-8")


def attach(app, book) -> None:
    import threading
    import tkinter as tk
    from tkinter import filedialog, ttk

    from PIL import Image

    BG, SURFACE, FG, MUTED, PRIMARY = "#12110f", "#1c1a17", "#f4efe6", "#a39b90", "#e23d2b"
    frame = ttk.Frame(book, style="TFrame")
    book.add(frame, text="Cards")
    frame.columnconfigure(1, weight=1)
    frame.rowconfigure(0, weight=1)
    library = ttk.Frame(frame, style="Card.TFrame", padding=8)
    library.grid(row=0, column=0, sticky="nsw")
    ttk.Label(library, text="Card library", style="Card.TLabel").pack(anchor="w")
    ttk.Label(library, text="Every card you write is kept here.", style="Muted.TLabel", wraplength=210).pack(anchor="w", pady=(2, 6))
    find = tk.StringVar()
    tk.Entry(library, textvariable=find, bg=BG, fg=FG, insertbackground=FG, relief="flat").pack(fill="x", ipady=4)
    box = tk.Listbox(
        library,
        width=28,
        height=24,
        bg=BG,
        fg=FG,
        selectbackground=PRIMARY,
        activestyle="none",
        relief="flat",
        highlightthickness=0,
    )
    box.pack(fill="both", expand=True, pady=(6, 6))
    host = ttk.Frame(frame, style="TFrame")
    host.grid(row=0, column=1, sticky="nsew")
    form = app._make_scroller(host, bg=SURFACE, style="Card.TFrame")

    def label(text: str) -> None:
        ttk.Label(form, text=text, style="Card.TLabel").pack(anchor="w", pady=(8, 0))

    def entry(variable, secret: bool = False) -> None:
        tk.Entry(
            form,
            textvariable=variable,
            show="*" if secret else "",
            bg=BG,
            fg=FG,
            insertbackground=FG,
            relief="flat",
        ).pack(fill="x", pady=(4, 0))

    def area(height: int) -> tk.Text:
        widget = tk.Text(form, height=height, bg=BG, fg=FG, insertbackground=FG, relief="flat", wrap="word")
        widget.pack(fill="x", pady=(4, 0))
        return widget

    stored = load_settings()
    concept = tk.Text(form, height=4, bg=BG, fg=FG, insertbackground=FG, relief="flat", wrap="word")
    current_id = tk.StringVar()
    shown: list[str] = []
    kobold = tk.StringVar(value=stored["kobold"])
    key = tk.StringVar(value=stored["key"])
    model = tk.StringVar(value=stored["model"])
    novel_token = tk.StringVar(value=str(stored.get("novel_token") or ""))
    novel_model = tk.StringVar(value=str(stored.get("novel_model") or DEFAULT_NOVEL_MODEL))
    novel_seed = tk.StringVar(value=str(stored.get("novel_seed") or "-1"))
    novel_style = tk.StringVar(value=str(stored.get("novel_style") or "Anime"))
    novel_danbooru = tk.BooleanVar(value=bool(stored.get("novel_danbooru", True)))
    novel_steps = tk.IntVar(value=int(stored.get("novel_steps") or 25))
    novel_guidance = tk.DoubleVar(value=float(stored.get("novel_guidance") if stored.get("novel_guidance") is not None else 6.8))
    novel_rescale = tk.DoubleVar(value=float(stored.get("novel_rescale") or 0))
    novel_uc = tk.IntVar(value=int(stored.get("novel_uc") if stored.get("novel_uc") is not None else 2))
    novel_sampler = tk.StringVar(value=str(stored.get("novel_sampler") or "k_euler_ancestral"))
    novel_schedule = tk.StringVar(value=str(stored.get("novel_schedule") or "karras"))
    novel_auto = tk.BooleanVar(value=bool(stored.get("novel_auto")))
    novel_width = tk.IntVar(value=int(stored.get("novel_width") or 1024))
    novel_height = tk.IntVar(value=int(stored.get("novel_height") or 1024))
    novel_strength = tk.DoubleVar(value=float(stored.get("novel_strength") if stored.get("novel_strength") is not None else 0.65))
    novel_fidelity = tk.DoubleVar(value=float(stored.get("novel_fidelity") if stored.get("novel_fidelity") is not None else 0.65))
    novel_plate = tk.StringVar(value=str(stored.get("novel_plate") or ""))
    fields: dict[str, tk.Text] = {}
    novel_prefix = tk.Text(form, height=3, bg=BG, fg=FG, insertbackground=FG, relief="flat", wrap="word")
    novel_negative = tk.Text(form, height=3, bg=BG, fg=FG, insertbackground=FG, relief="flat", wrap="word")
    if stored.get("novel_prefix"):
        novel_prefix.insert("1.0", str(stored.get("novel_prefix")))
    if stored.get("novel_negative"):
        novel_negative.insert("1.0", str(stored.get("novel_negative")))
    talk = tk.IntVar(value=50)
    status = tk.Label(form, text="Idle", bg=SURFACE, fg=MUTED, wraplength=720, justify="left")

    def say(message: str) -> None:
        status.configure(text=message)

    def snapshot() -> dict:
        card = blank_card()
        for name, widget in fields.items():
            card[name] = widget.get("1.0", "end").strip()
        card["talkativeness"] = max(0, min(100, int(talk.get() or 0)))
        return card

    def show(card: dict) -> None:
        card = normalize_card(card)
        for name, widget in fields.items():
            widget.delete("1.0", "end")
            widget.insert("1.0", card.get(name, ""))
        talk.set(int(card["talkativeness"]))

    def remember() -> None:
        save_settings(
            {
                "kobold": kobold.get().strip() or DEFAULT_KOBOLD,
                "key": key.get(),
                "model": model.get().strip() or "koboldcpp",
                "temperature": 0.8,
                "max_tokens": 2200,
                "novel_token": novel_token.get(),
                "novel_model": novel_model.get().strip() or DEFAULT_NOVEL_MODEL,
                "novel_seed": novel_seed.get().strip() or "-1",
                "novel_style": novel_style.get().strip() or "Anime",
                "novel_danbooru": bool(novel_danbooru.get()),
                "novel_steps": int(novel_steps.get() or 25),
                "novel_guidance": float(novel_guidance.get() or 6.8),
                "novel_rescale": float(novel_rescale.get() or 0),
                "novel_uc": int(novel_uc.get() or 0),
                "novel_prefix": novel_prefix.get("1.0", "end").strip(),
                "novel_negative": novel_negative.get("1.0", "end").strip(),
                "novel_sampler": novel_sampler.get().strip() or "k_euler_ancestral",
                "novel_schedule": novel_schedule.get().strip() or "karras",
                "novel_auto": bool(novel_auto.get()),
                "novel_width": int(novel_width.get() or 1024),
                "novel_height": int(novel_height.get() or 1024),
                "novel_strength": float(novel_strength.get() or 0.65),
                "novel_fidelity": float(novel_fidelity.get() or 0.65),
                "novel_plate": novel_plate.get().strip(),
            }
        )

    def run(work, ok) -> None:
        say("Working…")

        def task() -> None:
            try:
                result = work()
            except Exception as exc:
                detail = str(exc)
                app.after(0, lambda detail=detail: say(detail))
                return
            app.after(0, lambda result=result: ok(result))

        threading.Thread(target=task, daemon=True).start()

    def on_card(card: dict, note: str) -> None:
        show(card)
        persist(normalize_card(card), concept.get("1.0", "end"), new=True)
        say(note + " Saved to the card library.")

    def refresh_library() -> None:
        box.unbind("<<ListboxSelect>>")
        shown.clear()
        box.delete(0, "end")
        query = find.get().strip().lower()
        chosen = current_id.get()
        pick = None
        for entry in load_library():
            name = str((entry.get("card") or {}).get("name") or "Unnamed")
            concept_text = str(entry.get("concept") or "")
            if query and query not in name.lower() and query not in concept_text.lower():
                continue
            shown.append(str(entry["id"]))
            box.insert("end", name)
            if entry["id"] == chosen:
                pick = len(shown) - 1
        if pick is not None:
            box.selection_set(pick)
            box.see(pick)
        box.bind("<<ListboxSelect>>", open_saved)

    def persist(card: dict, concept_text: str, *, new: bool) -> None:
        if not (str(card.get("name") or "").strip() or str(card.get("summary") or "").strip() or str(card.get("description") or "").strip()):
            return
        if new or not current_id.get():
            current_id.set(uuid.uuid4().hex)
        entry = {"id": current_id.get(), "concept": concept_text.strip(), "card": normalize_card(card)}
        write_library(merge_library(load_library(), entry))
        refresh_library()

    def open_saved(_event=None) -> None:
        selected = box.curselection()
        if not selected:
            return
        wanted = shown[selected[0]]
        entry = next((item for item in load_library() if item.get("id") == wanted), None)
        if entry is None:
            return
        current_id.set(wanted)
        show(entry["card"])
        concept.delete("1.0", "end")
        concept.insert("1.0", str(entry.get("concept") or ""))
        say(f"Opened {entry['card'].get('name') or 'the card'}.")

    def remove_saved() -> None:
        selected = box.curselection()
        if not selected:
            return
        wanted = shown[selected[0]]
        write_library([item for item in load_library() if item.get("id") != wanted])
        if current_id.get() == wanted:
            current_id.set("")
        refresh_library()
        say("Removed that card from the library.")

    box.bind("<<ListboxSelect>>", open_saved)
    find.trace_add("write", lambda *_args: refresh_library())
    ttk.Button(library, text="Remove", command=remove_saved).pack(anchor="w")
    refresh_library()

    label("Concept")
    ttk.Label(
        form,
        text="The prompt. Write card fills the whole card. Generate beside a field fills only that field.",
        style="Muted.TLabel",
        wraplength=720,
    ).pack(anchor="w")
    concept.pack(fill="x", pady=(4, 0))

    label("Kobold address")
    entry(kobold)
    label("API key, if Kobold has a password")
    entry(key, secret=True)
    label("Model")
    entry(model)

    row = ttk.Frame(form, style="Card.TFrame")
    row.pack(fill="x", pady=(10, 0))

    def ping() -> None:
        remember()
        run(lambda: kobold_ping(kobold.get(), key.get()), lambda note: say(note))

    def generate(persona: bool) -> None:
        remember()
        text = concept.get("1.0", "end")

        def work():
            if persona:
                return write_persona(kobold.get(), key.get(), text, model=model.get())
            return write_card(kobold.get(), key.get(), text, model=model.get())

        kind = "persona" if persona else "card"
        run(work, lambda card: on_card(card, f"Wrote the {kind}."))

    ttk.Button(row, text="Test Kobold", command=ping).pack(side="left")
    ttk.Button(row, text="Write card", style="Primary.TButton", command=lambda: generate(False)).pack(side="left", padx=8)
    ttk.Button(row, text="Write persona", command=lambda: generate(True)).pack(side="left")

    for name, guide in (
        ("name", "Name"),
        ("summary", "Summary"),
        ("description", "Description"),
        ("personality", "Personality"),
        ("backstory", "Backstory"),
        ("appearance", "Appearance"),
        ("scenario", "Scenario"),
        ("first_mes", "First message"),
        ("mes_example", "Examples"),
        ("creator_notes", "Creator notes"),
    ):
        head = ttk.Frame(form, style="Card.TFrame")
        head.pack(fill="x", pady=(8, 0))
        ttk.Label(head, text=guide, style="Card.TLabel").pack(side="left")

        def fill(field: str = name, title: str = guide) -> None:
            remember()
            prompt = concept.get("1.0", "end")

            def work() -> str:
                return rewrite_field(kobold.get(), key.get(), prompt, snapshot(), field, model=model.get())

            def ok(value: str) -> None:
                widget = fields[field]
                widget.delete("1.0", "end")
                widget.insert("1.0", value.strip())
                persist(snapshot(), prompt, new=False)
                say(f"Filled {title} from the prompt and saved the card.")

            run(work, ok)

        ttk.Button(head, text="Generate", command=fill).pack(side="right")
        fields[name] = area(3 if name != "name" else 1)
    label("Talkativeness, 0 to 100")
    tk.Spinbox(form, from_=0, to=100, textvariable=talk, bg=BG, fg=FG, relief="flat").pack(anchor="w", pady=(4, 0))

    actions = ttk.Frame(form, style="Card.TFrame")
    actions.pack(fill="x", pady=(12, 4))

    def use_prompt() -> None:
        prompt = novel_prompt(snapshot())
        if not prompt:
            say("Write an appearance first.")
            return
        app.prompt.delete("1.0", "end")
        app.prompt.insert("1.0", prompt)
        app.book.select(0)
        say("Appearance is now the Generate prompt.")

    def draw_redgen() -> None:
        use_prompt()
        if not app._models:
            say("Add a model on Generate, then press Generate.")
            return
        app._generate()

    def draw_novel() -> None:
        text = novel_prompt(snapshot())
        if text:
            novel_prompt_box.delete("1.0", "end")
            novel_prompt_box.insert("1.0", text)
        app.book.select(novel_tab)
        draw_on_novel()

    def save_json() -> None:
        card = snapshot()
        path = filedialog.asksaveasfilename(
            title="Save Character Card V2",
            defaultextension=".json",
            initialfile=f"{slug(card['name'])}.json",
            filetypes=[("JSON", "*.json")],
        )
        if not path:
            return
        Path(path).write_text(json.dumps(to_v2(card), indent=2, ensure_ascii=False), encoding="utf-8")
        say("Saved a Character Card V2 file. Marinara imports it as JSON.")

    def save_png() -> None:
        card = snapshot()
        image = getattr(app, "_full_image", None)
        plate = image if image is not None else text_plate(card)
        path = filedialog.asksaveasfilename(
            title="Save PNG card",
            defaultextension=".png",
            initialfile=f"{slug(card['name'])}.png",
            filetypes=[("PNG", "*.png")],
        )
        if not path:
            return
        Path(path).write_bytes(pack_png(plate, card))
        note = "portrait" if image is not None else "text plate"
        say(f"Saved a PNG card. The picture is the {note}, and the card JSON is stored inside the file.")

    def load_file() -> None:
        path = filedialog.askopenfilename(title="Open a card", filetypes=[("Card", "*.json *.png"), ("All", "*.*")])
        if not path:
            return
        file = Path(path)
        if file.suffix.lower() == ".png":
            card = read_png_card(file)
            if card is None:
                say("That PNG has no character card in it.")
                return
            try:
                app._full_image = Image.open(file).convert("RGB")
                app._show_frame(app._full_image, card["name"] or file.name)
            except OSError:
                pass
        else:
            try:
                card = normalize_card(json.loads(file.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError):
                say("That file is not a Cardwright card.")
                return
        show(card)
        persist(card, concept.get("1.0", "end"), new=True)
        say(f"Loaded {file.name}. Saved to the card library.")

    ttk.Button(actions, text="Use appearance as prompt", command=use_prompt).pack(side="left")
    ttk.Button(actions, text="Draw with RedGen", command=draw_redgen).pack(side="left", padx=8)
    ttk.Button(actions, text="Draw with NovelAI", command=draw_novel).pack(side="left")
    file_row = ttk.Frame(form, style="Card.TFrame")
    file_row.pack(fill="x", pady=(8, 0))
    ttk.Button(file_row, text="Save JSON", command=save_json).pack(side="left")
    ttk.Button(file_row, text="Save PNG", command=save_png).pack(side="left", padx=8)
    ttk.Button(file_row, text="Open", command=load_file).pack(side="left")
    status.pack(anchor="w", pady=(10, 4))

    novel_tab = ttk.Frame(book, style="TFrame")
    book.add(novel_tab, text="NovelAI")
    novel_tab.columnconfigure(0, weight=1)
    novel_tab.columnconfigure(1, weight=1)
    novel_tab.rowconfigure(0, weight=1)
    left_host = ttk.Frame(novel_tab, style="TFrame")
    left_host.grid(row=0, column=0, sticky="nsew")
    right_host = ttk.Frame(novel_tab, style="TFrame")
    right_host.grid(row=0, column=1, sticky="nsew")
    left = app._make_scroller(left_host, bg=SURFACE, style="Card.TFrame")
    right = app._make_scroller(right_host, bg=SURFACE, style="Card.TFrame")
    from PIL import ImageTk

    novel_status = tk.Label(left, text="Idle", bg=SURFACE, fg=MUTED, wraplength=420, justify="left")

    def novel_say(message: str) -> None:
        novel_status.configure(text=message)

    def novel_setup() -> dict:
        seed_text = novel_seed.get().strip()
        try:
            seed = int(seed_text) if seed_text else -1
        except ValueError:
            seed = -1
        return {
            "model": novel_model.get(),
            "prefix": novel_prefix.get("1.0", "end"),
            "negative": novel_negative.get("1.0", "end"),
            "width": int(novel_width.get() or 1024),
            "height": int(novel_height.get() or 1024),
            "steps": int(novel_steps.get() or 25),
            "guidance": float(novel_guidance.get() or 6.8),
            "seed": seed,
            "rescale": float(novel_rescale.get() or 0),
            "uc": int(novel_uc.get() or 0),
            "sampler": novel_sampler.get(),
            "schedule": novel_schedule.get(),
            "auto": bool(novel_auto.get()),
            "plate": novel_plate.get(),
            "strength": float(novel_strength.get() or 0.65),
            "fidelity": float(novel_fidelity.get() or 0.65),
        }

    ttk.Label(left, text="Prompt", style="Card.TLabel").pack(anchor="w")
    novel_prompt_box = tk.Text(left, height=8, bg=BG, fg=FG, insertbackground=FG, relief="flat", wrap="word")
    novel_prompt_box.pack(fill="x", pady=(4, 6))
    prompt_row = ttk.Frame(left, style="Card.TFrame")
    prompt_row.pack(fill="x", pady=(0, 6))

    def use_appearance() -> None:
        text = novel_prompt(snapshot())
        novel_prompt_box.delete("1.0", "end")
        novel_prompt_box.insert("1.0", text)
        width, height = novel_size(text, int(novel_width.get() or 1024), int(novel_height.get() or 1024), bool(novel_auto.get()))
        novel_say(f"Appearance is the prompt. Requested size is {width}×{height} unless character count changes it.")

    def show_novel_image(image) -> None:
        copy = image.copy()
        copy.thumbnail((440, 620))
        photo = ImageTk.PhotoImage(copy)
        novel_view.image = photo
        novel_view.delete("all")
        novel_view.create_image(220, 300, image=photo)
        novel_caption.configure(text=snapshot()["name"].strip() or "Picture")

    def draw_on_novel() -> None:
        remember()
        prompt = novel_prompt_box.get("1.0", "end")
        setup = novel_setup()

        def work():
            return novel_generate(novel_token.get(), prompt, setup)

        def ok(image) -> None:
            app._full_image = image
            show_novel_image(image)
            if hasattr(app, "_show_frame"):
                app._show_frame(image, snapshot()["name"].strip() or "Portrait")
            novel_say("Picture ready. Save it, or use it on the card.")

        novel_say("Drawing with NovelAI…")

        def task() -> None:
            try:
                image = work()
            except Exception as exc:
                detail = str(exc)
                app.after(0, lambda detail=detail: novel_say(detail))
                return
            app.after(0, lambda image=image: ok(image))

        threading.Thread(target=task, daemon=True).start()

    def test_novel() -> None:
        remember()

        def task() -> None:
            try:
                note = novel_ping(novel_token.get())
            except Exception as exc:
                detail = str(exc)
                app.after(0, lambda detail=detail: novel_say(detail))
                return
            app.after(0, lambda note=note: novel_say(note))

        novel_say("Checking the NovelAI token…")
        threading.Thread(target=task, daemon=True).start()

    ttk.Button(prompt_row, text="Use appearance", command=use_appearance).pack(side="left")
    ttk.Button(prompt_row, text="Draw", style="Primary.TButton", command=draw_on_novel).pack(side="left", padx=8)
    ttk.Button(prompt_row, text="Test NovelAI", command=test_novel).pack(side="left")
    novel_caption = tk.Label(left, text="No picture yet", bg=SURFACE, fg=FG)
    novel_caption.pack(anchor="w", pady=(8, 0))
    novel_view = tk.Canvas(left, bg=BG, height=460, highlightthickness=0)
    novel_view.pack(fill="x", pady=(4, 6))
    picture_row = ttk.Frame(left, style="Card.TFrame")
    picture_row.pack(fill="x")

    def save_picture() -> None:
        image = getattr(app, "_full_image", None)
        if image is None:
            novel_say("Draw a picture first.")
            return
        path = filedialog.asksaveasfilename(title="Save picture", defaultextension=".png", filetypes=[("PNG", "*.png")])
        if path:
            image.save(path)
            novel_say("Saved the picture.")

    def use_on_card() -> None:
        if getattr(app, "_full_image", None) is None:
            novel_say("Draw a picture first.")
            return
        novel_say("This picture is now the card portrait. Save PNG on Cards to pack it in.")

    ttk.Button(picture_row, text="Save", style="Primary.TButton", command=save_picture).pack(side="left")
    ttk.Button(picture_row, text="Use on card", command=use_on_card).pack(side="left", padx=8)
    novel_status.pack(anchor="w", pady=(8, 4))

    ttk.Label(right, text="Account", style="Card.TLabel").pack(anchor="w")
    ttk.Label(right, text="Persistent token", style="Muted.TLabel").pack(anchor="w", pady=(6, 0))
    tk.Entry(right, textvariable=novel_token, show="*", bg=BG, fg=FG, insertbackground=FG, relief="flat").pack(fill="x", ipady=4)
    ttk.Label(right, text="The pst- token stays on this computer and is sent only to NovelAI.", style="Muted.TLabel", wraplength=420).pack(anchor="w")
    ttk.Label(right, text="Model", style="Muted.TLabel").pack(anchor="w", pady=(8, 0))
    model_names = [label for label, _mid in NOVEL_MODELS]
    model_ids = {label: mid for label, mid in NOVEL_MODELS}
    model_labels = {mid: label for label, mid in NOVEL_MODELS}
    model_label = tk.StringVar(value=model_labels.get(novel_model.get(), "V5 Full"))
    plate_note = tk.Label(right, text="", bg=SURFACE, fg=MUTED, wraplength=420, justify="left")

    def apply_model(*_args) -> None:
        novel_model.set(model_ids.get(model_label.get(), DEFAULT_NOVEL_MODEL))
        if "diffusion-5" in novel_model.get():
            plate_note.configure(text="V5 does not take a style plate. Switch to V4.5 to use it.")
        else:
            plate_note.configure(text="A persistent style-only reference applied first to every V4.5 generation, including scenes without characters.")

    ttk.Combobox(right, textvariable=model_label, values=model_names, state="readonly").pack(fill="x", pady=(2, 0))
    model_label.trace_add("write", apply_model)

    ttk.Label(right, text="NovelAI generation setup", style="Card.TLabel").pack(anchor="w", pady=(14, 0))
    ttk.Label(right, text="Prompt prefixes, sampler, scheduler, steps, guidance, seed, and resolution.", style="Muted.TLabel", wraplength=420).pack(anchor="w")
    ttk.Label(right, text="Seed -1 keeps generation random. Any non-negative seed is reused exactly.", style="Muted.TLabel", wraplength=420).pack(anchor="w", pady=(6, 0))

    def reset_novel() -> None:
        novel_seed.set("-1")
        novel_style.set("Anime")
        novel_danbooru.set(True)
        novel_steps.set(25)
        novel_guidance.set(6.8)
        novel_rescale.set(0)
        novel_uc.set(2)
        novel_sampler.set("k_euler_ancestral")
        novel_schedule.set("karras")
        novel_auto.set(False)
        novel_width.set(1024)
        novel_height.set(1024)
        novel_strength.set(0.65)
        novel_fidelity.set(0.65)
        novel_prefix.delete("1.0", "end")
        novel_negative.delete("1.0", "end")
        novel_say("Reset the NovelAI setup.")

    ttk.Button(right, text="Reset", command=reset_novel).pack(anchor="e", pady=(4, 0))

    def labeled_entry(parent, title, variable):
        ttk.Label(parent, text=title, style="Muted.TLabel").pack(anchor="w", pady=(8, 0))
        tk.Entry(parent, textvariable=variable, bg=BG, fg=FG, insertbackground=FG, relief="flat").pack(fill="x", ipady=4)

    labeled_entry(right, "Seed", novel_seed)
    style_head = ttk.Frame(right, style="Card.TFrame")
    style_head.pack(fill="x", pady=(8, 0))
    ttk.Label(style_head, text="Style profile", style="Muted.TLabel").pack(side="left")

    def use_danbooru() -> None:
        novel_style.set("Anime")
        novel_danbooru.set(True)
        novel_say("Style profile set from Danbooru / Illustrious.")

    ttk.Button(style_head, text="Use Danbooru / Illustrious", command=use_danbooru).pack(side="right")
    ttk.Combobox(right, textvariable=novel_style, values=("Anime", "Semi-realistic", "Furry"), state="readonly").pack(fill="x", pady=(2, 0))
    ttk.Label(right, text="Suggested from model/source: Danbooru / Illustrious", style="Muted.TLabel").pack(anchor="w")
    labeled_entry(right, "Steps", novel_steps)
    labeled_entry(right, "Prompt guidance", novel_guidance)
    labeled_entry(right, "Guidance rescale", novel_rescale)
    labeled_entry(right, "UC preset", novel_uc)
    ttk.Label(right, text="UC preset: 0 heavy, 1 light, 2 human focus, 3 none, 4 as in your setup.", style="Muted.TLabel", wraplength=420).pack(anchor="w")
    ttk.Label(right, text="Prompt prefix", style="Muted.TLabel").pack(anchor="w", pady=(8, 0))
    novel_prefix.pack(in_=right, fill="x", pady=(2, 0))
    ttk.Label(right, text="Negative prefix", style="Muted.TLabel").pack(anchor="w", pady=(8, 0))
    novel_negative.pack(in_=right, fill="x", pady=(2, 0))
    labeled_entry(right, "Sampler", novel_sampler)
    labeled_entry(right, "Noise schedule", novel_schedule)
    tk.Checkbutton(
        right,
        text="Choose resolution from character count",
        variable=novel_auto,
        bg=SURFACE,
        fg=FG,
        selectcolor=BG,
        activebackground=SURFACE,
        activeforeground=FG,
    ).pack(anchor="w", pady=(8, 0))
    ttk.Label(
        right,
        text="Uses portrait for one subject, square for two, and landscape for three or more. Free-form prompts without a detectable count keep the requested size.",
        style="Muted.TLabel",
        wraplength=420,
    ).pack(anchor="w")
    labeled_entry(right, "Width", novel_width)
    labeled_entry(right, "Height", novel_height)
    ttk.Label(right, text="NovelAI V4.5 style plate", style="Card.TLabel").pack(anchor="w", pady=(12, 0))
    plate_note.pack(anchor="w")

    def choose_plate() -> None:
        path = filedialog.askopenfilename(title="Style plate", filetypes=[("Pictures", "*.png *.jpg *.jpeg *.webp"), ("All", "*.*")])
        if path:
            novel_plate.set(path)
            novel_say("Style plate selected. V4.5 uses it. V5 ignores it.")

    ttk.Button(right, text="Choose image", command=choose_plate).pack(anchor="w", pady=(4, 0))
    ttk.Label(right, textvariable=novel_plate, style="Muted.TLabel", wraplength=420).pack(anchor="w")
    labeled_entry(right, "Style strength", novel_strength)
    labeled_entry(right, "Style fidelity", novel_fidelity)
    apply_model()

    def remember_card() -> None:
        remember()
        persist(snapshot(), concept.get("1.0", "end"), new=False)

    app.cards_remember = remember_card


def selftest() -> int:
    from PIL import Image

    card = normalize_card(
        {
            "spec": "chara_card_v2",
            "data": {
                "name": "June Pell",
                "description": "Keeps the clinic calendar.",
                "extensions": {"talkativeness": 140, "appearance": "short brown hair, wool coat"},
                "tags": ["town", ""],
            },
        }
    )
    assert card["name"] == "June Pell"
    assert card["talkativeness"] == 100
    assert card["appearance"] == "short brown hair, wool coat"
    assert card["tags"] == ["town"]
    packed = to_v2(card)
    assert packed["spec"] == "chara_card_v2"
    assert packed["data"]["extensions"]["appearance"].startswith("short")
    assert kobold_root("127.0.0.1:5001") == "http://127.0.0.1:5001/v1"
    assert kobold_root("http://127.0.0.1:5001/v1/") == "http://127.0.0.1:5001/v1"
    image = text_plate(card)
    raw = pack_png(image, card)
    path = Path(__file__).resolve().parent / "_selftest_card.png"
    path.write_bytes(raw)
    try:
        loaded = read_png_card(path)
        assert loaded is not None and loaded["name"] == "June Pell"
        with Image.open(path) as check:
            assert check.size == (832, 1216)
    finally:
        path.unlink(missing_ok=True)
    prompt = novel_prompt(card)
    assert "wool coat" in prompt
    counted = novel_body(
        "1girl, red coat",
        {
            "model": "nai-diffusion-5-full",
            "prefix": "score_9",
            "negative": "low quality",
            "width": 1024,
            "height": 1024,
            "steps": 25,
            "guidance": 6.8,
            "seed": 5,
            "uc": 2,
            "sampler": "k_euler_ancestral",
            "schedule": "karras",
            "rescale": 0,
            "auto": True,
            "plate": "missing.png",
        },
    )
    assert counted["parameters"]["params_version"] == 4
    assert counted["parameters"]["ucPreset"] == 2
    assert counted["parameters"]["sampler"] == "k_euler_ancestral"
    assert counted["parameters"]["width"] == 832 and counted["parameters"]["height"] == 1216
    assert "reference_image_multiple" not in counted["parameters"]
    assert counted["input"].startswith("score_9")
    assert novel_size("1girl and 1boy", 832, 1216, True) == (1024, 1024)
    assert novel_size("a quiet room", 1024, 1024, True) == (1024, 1024)
    merged = merge_library([{"id": "a", "card": {"name": "Old"}}], {"id": "b", "card": {"name": "New"}})
    assert [item["id"] for item in merged] == ["b", "a"]
    merged = merge_library(merged, {"id": "b", "card": {"name": "Newer"}})
    assert len(merged) == 2 and merged[0]["card"]["name"] == "Newer"
    print("cardwright selftest ok")
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--selftest":
        raise SystemExit(selftest())
    print("Open Redwright from redgen.py. This file is the card generator it imports.", flush=True)
