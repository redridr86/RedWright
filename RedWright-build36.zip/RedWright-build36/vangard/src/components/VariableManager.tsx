/**
 * @file VariableManager.tsx
 * @description Virtualised list of `default`/`define`/`persistent`/`implicit` variables from project scripts (~200 lines).
 * Key features: persistence-type colour badges with tooltips, initial-value display, hover
 * highlight integration, find-usages action, add-variable form.
 * Integration: rendered as a sidebar panel; variable data comes from `useRenpyAnalysis`;
 * hover highlights propagate to `StoryCanvas` via `onHoverHighlightStart`/`End`.
 */
import React, { useState, useMemo } from 'react';
import type { Variable, RenpyAnalysisResult } from '@/types';
import { useVirtualList } from '@/hooks/useVirtualList';

// p-2 (16px) + name line (20px) + value line (16px) + badges line (20px) + space-y-2 gap (8px)
const VAR_ITEM_HEIGHT = 76;

interface VariableManagerProps {
    analysisResult: RenpyAnalysisResult;
    onAddVariable: (variable: Omit<Variable, 'definedInBlockId' | 'line'>) => void;
    onEditVariable: (oldName: string, updated: Omit<Variable, 'definedInBlockId' | 'line'>) => void;
    onFindUsages: (variableName: string) => void;
    onHoverHighlightStart: (key: string, type: 'character' | 'variable') => void;
    onHoverHighlightEnd: () => void;
    dismissedImplicitVarHint: boolean;
    onDismissImplicitVarHint: () => void;
    onOpenDiagnostics: () => void;
    prefill?: { name: string; initialValue: string } | null;
    onPrefillConsumed?: () => void;
}

const PERSISTENCE_INFO: Record<'persistent' | 'default' | 'define' | 'implicit', { label: string; color: string; tooltip: string }> = {
    persistent: {
        label: 'persistent',
        color: 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300',
        tooltip: 'Stored in renpy.persistent — survives new game and quit. Not rolled back.',
    },
    default: {
        label: 'default',
        color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
        tooltip: 'Saved to save files. Participates in rollback. Resets to initial value only if not in the save.',
    },
    define: {
        label: 'define',
        color: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300',
        tooltip: 'Constant — not saved, not rolled back. Value set once at game start and never changes during play.',
    },
    implicit: {
        label: 'implicit',
        color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
        tooltip: 'Created by a "$ name = value" assignment, not a real default/define statement. Only exists once that line has run — referencing it earlier will error. Consider converting to "default".',
    },
};

function getPersistenceKind(variable: Variable): 'persistent' | 'default' | 'define' | 'implicit' {
    if (variable.name.startsWith('persistent.')) return 'persistent';
    if (variable.type === 'define') return 'define';
    if (variable.type === 'implicit') return 'implicit';
    return 'default';
}

const SemanticBadge: React.FC<{ kind: 'persistent' | 'default' | 'define' | 'implicit' }> = ({ kind }) => {
    const info = PERSISTENCE_INFO[kind];
    return (
        <span
            className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold leading-none ${info.color}`}
            title={info.tooltip}
        >
            {info.label}
        </span>
    );
};

const VariableEditor: React.FC<{
    onSave: (variable: Omit<Variable, 'definedInBlockId' | 'line'>) => void;
    onCancel: () => void;
    existingNames: string[];
    editing?: Variable;
    prefillName?: string;
    prefillInitialValue?: string;
}> = ({ onSave, onCancel, existingNames, editing, prefillName, prefillInitialValue }) => {
    const [name, setName] = useState(editing?.name ?? prefillName ?? '');
    // Convert implicit/function to default when editing (these can't be manually created)
    const [type, setType] = useState<'define' | 'default'>(
        editing?.type === 'define' ? 'define' : 'default'
    );
    const [initialValue, setInitialValue] = useState(editing?.initialValue ?? prefillInitialValue ?? 'False');
    const [nameError, setNameError] = useState('');

    const isRename = editing && name !== editing.name;

    const handleSave = () => {
        const isNameValid = /^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(name) && name.length > 0;

        if (!isNameValid) {
            setNameError('Name must be a valid variable name (letters, numbers, underscores, dots).');
            return;
        }
        // Allow keeping the same name when editing; otherwise check uniqueness
        const isNameUnique = (editing && name === editing.name) || !existingNames.includes(name);
        if (!isNameUnique) {
            setNameError('This variable name is already in use.');
            return;
        }

        onSave({ name, type, initialValue });
    };

    React.useEffect(() => {
        setNameError('');
    }, [name]);

    return (
        <div className="bg-gray-100 dark:bg-gray-700/50 p-4 rounded-lg space-y-3">
            <h3 className="font-semibold text-lg">{editing ? 'Edit Variable' : 'Add New Variable'}</h3>
            {isRename && (
                <div className="flex items-start gap-2 p-2.5 rounded-md bg-amber-50 dark:bg-amber-900/30 border border-amber-300 dark:border-amber-700 text-amber-800 dark:text-amber-200 text-xs">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                    <span>Saving will rename <code className="font-mono font-semibold">{editing.name}</code> to <code className="font-mono font-semibold">{name}</code> across all project files.</span>
                </div>
            )}
            <div>
                <label className="text-sm font-medium">Type</label>
                <select value={type} onChange={e => setType(e.target.value as 'define' | 'default')} className="w-full mt-1 p-2 rounded bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 focus:ring-indigo-500 focus:border-indigo-500">
                    <option value="default">default — saved to save files, rolls back</option>
                    <option value="define">define — constant, not saved</option>
                </select>
            </div>
            <div>
                <label className="text-sm font-medium">Variable Name</label>
                <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="e.g., player_score or persistent.seen_ending" className={`w-full mt-1 p-2 rounded bg-white dark:bg-gray-800 border ${nameError ? 'border-red-500' : 'border-gray-300 dark:border-gray-600'} focus:ring-indigo-500 focus:border-indigo-500`} />
                {nameError && <p className="text-red-500 text-xs mt-1">{nameError}</p>}
                <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">Use <code className="font-mono">persistent.</code> prefix for cross-save persistent variables.</p>
            </div>
            <div>
                <label className="text-sm font-medium">Initial Value</label>
                <input type="text" value={initialValue} onChange={e => setInitialValue(e.target.value)} placeholder={`e.g., 0 or "initial_state"`} className="w-full mt-1 p-2 rounded bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 focus:ring-indigo-500 focus:border-indigo-500" />
            </div>
            <div className="flex justify-end space-x-2 pt-2">
                <button onClick={onCancel} className="px-4 py-2 rounded bg-gray-200 dark:bg-gray-600 hover:bg-gray-300 dark:hover:bg-gray-500 text-sm font-bold">Cancel</button>
                <button onClick={handleSave} className="px-4 py-2 rounded bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold">Save</button>
            </div>
        </div>
    );
};


const VariableManager: React.FC<VariableManagerProps> = ({ analysisResult, onAddVariable, onEditVariable, onFindUsages, onHoverHighlightStart, onHoverHighlightEnd, dismissedImplicitVarHint, onDismissImplicitVarHint, onOpenDiagnostics, prefill, onPrefillConsumed }) => {
    const { variables, variableUsages, storyBlockIds } = analysisResult;
    const [mode, setMode] = useState<'list' | 'add' | 'edit'>('list');
    const [editingVariable, setEditingVariable] = useState<Variable | null>(null);
    const [filterStoryVars, setFilterStoryVars] = useState(true);

    React.useEffect(() => {
        if (prefill) {
            setMode('add');
        }
    }, [prefill]);

    const filteredVariables = useMemo(() => {
        // Python-block functions aren't save-persistence variables — they belong in
        // the editor's completion list, not this panel.
        const allVars = Array.from(variables.values()).filter((v: Variable) => v.type !== 'function');
        if (!filterStoryVars) return allVars;
        return allVars.filter((v: Variable) => storyBlockIds.has(v.definedInBlockId));
    }, [variables, filterStoryVars, storyBlockIds]);

    // Count implicit variables
    const implicitVarCount = useMemo(() =>
        Array.from(analysisResult.variables.values())
            .filter(v => v.type === 'implicit').length,
        [analysisResult.variables]
    );

    const explicitVarCount = useMemo(() =>
        filteredVariables.filter(v => v.type !== 'implicit').length,
        [filteredVariables]
    );

    const shouldShowBanner = implicitVarCount >= 10 && explicitVarCount < 5 && !dismissedImplicitVarHint;

    const { persistent, defaulted, defined, implicit } = useMemo(() => {
        const grouped = { persistent: [] as Variable[], defaulted: [] as Variable[], defined: [] as Variable[], implicit: [] as Variable[] };
        for (const variable of filteredVariables) {
            const kind = getPersistenceKind(variable);
            if (kind === 'persistent') grouped.persistent.push(variable);
            else if (kind === 'define') grouped.defined.push(variable);
            else if (kind === 'implicit') grouped.implicit.push(variable);
            else grouped.defaulted.push(variable);
        }
        const sort = (a: Variable, b: Variable) => a.name.localeCompare(b.name);
        grouped.persistent.sort(sort);
        grouped.defaulted.sort(sort);
        grouped.defined.sort(sort);
        grouped.implicit.sort(sort);
        return grouped;
    }, [filteredVariables]);

    const handleSave = (variable: Omit<Variable, 'definedInBlockId' | 'line'>) => {
        onAddVariable(variable);
        setMode('list');
    };

    const handleEditSave = (updated: Omit<Variable, 'definedInBlockId' | 'line'>) => {
        if (editingVariable) {
            onEditVariable(editingVariable.name, updated);
        }
        setEditingVariable(null);
        setMode('list');
    };

    const enterEditMode = (variable: Variable) => {
        setEditingVariable(variable);
        setMode('edit');
    };

    const VariableList: React.FC<{ title: string; kind: 'persistent' | 'default' | 'define' | 'implicit'; vars: Variable[] }> = ({ title, kind, vars }) => {
        const [collapsed, setCollapsed] = useState(false);
        const { containerRef, handleScroll, virtualItems, totalHeight } = useVirtualList(
            collapsed ? [] : vars,
            VAR_ITEM_HEIGHT,
        );
        return (
            <div className="mt-4">
                <button
                    onClick={() => setCollapsed(c => !c)}
                    className="flex items-center gap-2 w-full font-semibold text-gray-500 dark:text-gray-400 text-sm mb-2 hover:text-gray-700 dark:hover:text-gray-200 transition-colors"
                >
                    <svg className={`w-3 h-3 flex-none transition-transform ${collapsed ? '-rotate-90' : ''}`} viewBox="0 0 12 12" fill="none">
                        <path d="M2 4L6 8L10 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                    <SemanticBadge kind={kind} />
                    <span>{title} ({vars.length})</span>
                </button>
                {!collapsed && (
                    vars.length === 0
                        ? <p className="text-xs text-gray-400 dark:text-gray-500 pl-1">None found.</p>
                        : (
                            <div
                                ref={containerRef}
                                className="relative"
                                onScroll={handleScroll}
                            >
                                <div style={{ height: totalHeight, position: 'relative' }}>
                                    {virtualItems.map(({ item: variable, offsetTop }) => {
                                        const usageCount = variableUsages.get(variable.name)?.length ?? 0;
                                        const isUnused = usageCount === 0;
                                        return (
                                            <div
                                                key={variable.name}
                                                style={{ position: 'absolute', top: offsetTop, left: 0, right: 0, height: VAR_ITEM_HEIGHT - 8 }}
                                                className="p-2 rounded-md bg-gray-50 dark:bg-gray-700/50 flex items-center justify-between"
                                                onMouseEnter={() => onHoverHighlightStart(variable.name, 'variable')}
                                                onMouseLeave={onHoverHighlightEnd}
                                                onDoubleClick={() => enterEditMode(variable)}
                                            >
                                                <div className="flex-grow min-w-0">
                                                    <p className="font-semibold font-mono text-sm truncate" title={variable.name}>{variable.name}</p>
                                                    <p className="text-xs text-gray-500 dark:text-gray-400 truncate" title={`= ${variable.initialValue}`}>
                                                        = {variable.initialValue}
                                                    </p>
                                                    <div className="flex items-center gap-1.5 mt-0.5">
                                                        <span
                                                            className={`text-[10px] font-mono px-1.5 py-0.5 rounded leading-none ${
                                                                isUnused
                                                                    ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300'
                                                                    : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'
                                                            }`}
                                                            title={isUnused ? 'This variable is never referenced in code' : `Referenced ${usageCount} time${usageCount !== 1 ? 's' : ''} in code`}
                                                        >
                                                            {isUnused ? 'unused' : `${usageCount} use${usageCount !== 1 ? 's' : ''}`}
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="flex items-center space-x-1 flex-shrink-0 pl-2">
                                                    <button
                                                        onClick={() => onFindUsages(variable.name)}
                                                        title="Find Usages"
                                                        className="p-1 text-gray-500 hover:text-indigo-600 dark:hover:text-indigo-400 rounded"
                                                    >
                                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                                                    </button>
                                                    <button
                                                        onClick={() => enterEditMode(variable)}
                                                        title="Edit Variable"
                                                        className="p-1 text-gray-500 hover:text-indigo-600 dark:hover:text-indigo-400 rounded"
                                                    >
                                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /></svg>
                                                    </button>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        )
                )}
            </div>
        );
    };

    return (
        <>
            {mode === 'list' && (
                <>
                    {shouldShowBanner && (
                        <div className="mx-2 mb-3 flex items-start gap-2 p-2.5 rounded-md bg-blue-50 dark:bg-blue-900/30 border border-blue-300 dark:border-blue-700 text-blue-800 dark:text-blue-200 text-xs">
                            <svg className="h-4 w-4 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                            </svg>
                            <div className="flex-1">
                                <div className="font-medium mb-1">Implicit Variables Detected</div>
                                <div>
                                    This project uses {implicitVarCount} implicit variable definition{implicitVarCount !== 1 ? 's' : ''}
                                    (shown below under "Implicit"). These are "$ name = value" assignments, not real
                                    default/define statements — they only exist once that line has run.
                                </div>
                            </div>
                            <div className="flex gap-2 mt-1">
                                <button
                                    onClick={onOpenDiagnostics}
                                    className="text-blue-700 dark:text-blue-300 underline hover:no-underline text-xs whitespace-nowrap"
                                >
                                    View in Diagnostics
                                </button>
                                <button
                                    onClick={onDismissImplicitVarHint}
                                    className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200"
                                    title="Don't show again"
                                >
                                    ×
                                </button>
                            </div>
                        </div>
                    )}

                    <div className="flex items-center justify-between mb-4">
                        <label htmlFor="variable-filter-toggle" className="flex items-center gap-3 cursor-pointer">
                            <span className="text-sm text-gray-600 dark:text-gray-400 select-none">
                                Show story variables only
                            </span>
                            <div className="relative inline-flex items-center">
                                <input
                                    type="checkbox"
                                    id="variable-filter-toggle"
                                    className="sr-only peer"
                                    checked={filterStoryVars}
                                    onChange={() => setFilterStoryVars(!filterStoryVars)}
                                />
                                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 dark:peer-focus:ring-indigo-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-indigo-600"></div>
                            </div>
                        </label>
                        <button onClick={() => setMode('add')} className="px-2 py-1 rounded bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold">+ Add</button>
                    </div>

                    <div>
                        <VariableList title="Persistent" kind="persistent" vars={persistent} />
                        <VariableList title="Default" kind="default" vars={defaulted} />
                        <VariableList title="Defined" kind="define" vars={defined} />
                        <VariableList title="Implicit" kind="implicit" vars={implicit} />
                    </div>
                    {filteredVariables.length === 0 && (
                        <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-4">
                            {filterStoryVars ? 'No story variables found.' : 'No variables defined yet.'}
                        </p>
                    )}
                </>
            )}

            {mode === 'add' && (
                <VariableEditor
                    onSave={(variable) => { handleSave(variable); onPrefillConsumed?.(); }}
                    onCancel={() => { setMode('list'); onPrefillConsumed?.(); }}
                    existingNames={Array.from(variables.keys())}
                    prefillName={prefill?.name}
                    prefillInitialValue={prefill?.initialValue}
                />
            )}

            {mode === 'edit' && editingVariable && (
                <VariableEditor
                    onSave={handleEditSave}
                    onCancel={() => { setEditingVariable(null); setMode('list'); }}
                    existingNames={Array.from(variables.keys())}
                    editing={editingVariable}
                />
            )}
        </>
    );
};

export default VariableManager;
