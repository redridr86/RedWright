/**
 * @file StatsView.tsx
 * @description Project-wide statistics dashboard with multiple analysis tabs (~600 lines).
 * Key features: Story tab (word count, label/menu counts, branching metrics), Asset Coverage tab
 * (image/audio referenced/missing/orphaned table), Charts tab (label word-count bar chart).
 * Integration: opened as a static tab from `Toolbar`; reads `blocks`, `analysisResult`, route
 * analysis, image/audio metadata, and diagnostic counts from `App.tsx` props.
 */
import React, { useEffect, useMemo, useState } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, CartesianGrid,
} from 'recharts';
import type { Block, RenpyAnalysisResult, LabelNode, RouteLink, IdentifiedRoute, ProjectImage, ImageMetadata, RenpyAudio } from '@/types';
import type { PerformanceSnapshot } from '@/hooks/usePerformanceMetrics';
import { useCanvasFps } from '@/hooks/useCanvasFps';
import { buildKnownIdentifierSet, extractUndefinedVariableReferences } from '@/lib/renpyIdentifiers';
import { groupUsageLocations, type UsageLocationGroup } from '@/lib/usageLocations';
import { statsToMarkdown, statsToCSV, type StatsReportData } from '@/lib/exportReport';
import ExportMenu from '@/components/ExportMenu';

interface StatsViewProps {
  blocks: Block[];
  analysisResult: RenpyAnalysisResult;
  routeAnalysisResult: { labelNodes: LabelNode[]; routeLinks: RouteLink[]; identifiedRoutes: IdentifiedRoute[]; routesTruncated: boolean };
  projectImages: Map<string, ProjectImage>;
  imageMetadata: Map<string, ImageMetadata>;
  projectAudios: Map<string, RenpyAudio>;
  diagnosticsErrorCount: number;
  onOpenDiagnostics: () => void;
  onOpenEditor?: (blockId: string, line?: number) => void;
  performanceMetrics?: PerformanceSnapshot;
}

// ── Coverage types ────────────────────────────────────────────────────────────

interface CoverageRow {
  id: string;
  name: string;
  type: 'image' | 'audio';
  status: 'referenced' | 'missing' | 'orphaned';
}

type CoverageTypeFilter = 'all' | 'image' | 'audio';
type CoverageStatusFilter = 'all' | 'referenced' | 'missing' | 'orphaned';
type CoverageSortKey = 'name' | 'status' | 'type';
type CoverageSortDir = 'asc' | 'desc';

type VariableCoverageStatusFilter = 'all' | 'referenced' | 'unreferenced';
type VariableCoverageSortKey = 'name' | 'status';
type VariableCoverageSortDir = 'asc' | 'desc';

interface VariableCoverageRow {
  name: string;
  type: string;
  status: 'referenced' | 'unreferenced';
  locations: UsageLocationGroup[];
}

function countWordsInScript(script: string): number {
  if (!script) return 0;
  const DIALOGUE_NARRATION_REGEX = /(?:[a-zA-Z0-9_]+\s)?"((?:\\.|[^"\\])*)"/g;
  let total = 0;
  let match;
  while ((match = DIALOGUE_NARRATION_REGEX.exec(script)) !== null) {
    const text = match[1];
    if (text) total += text.trim().split(/\s+/).filter(Boolean).length;
  }
  return total;
}

// ── Complexity ────────────────────────────────────────────────────────────────

type ComplexityBucket = 'Linear' | 'Branching' | 'Complex' | 'Non-linear';

function getComplexityBucket(branchingCount: number, totalBlocks: number, routeCount: number): ComplexityBucket {
  const ratio = branchingCount / Math.max(1, totalBlocks);
  if (ratio > 0.5 || routeCount > 30) return 'Non-linear';
  if (ratio > 0.25 || routeCount > 12) return 'Complex';
  if (ratio > 0.08 || routeCount > 3) return 'Branching';
  return 'Linear';
}

const COMPLEXITY_COLORS: Record<ComplexityBucket, string> = {
  Linear: '#22c55e',
  Branching: '#6366f1',
  Complex: '#f59e0b',
  'Non-linear': '#ef4444',
};

const COMPLEXITY_DESCRIPTIONS: Record<ComplexityBucket, string> = {
  Linear: 'Mainly one path through the story',
  Branching: 'Several distinct story paths',
  Complex: 'Many intersecting routes and choices',
  'Non-linear': 'Highly interconnected — large route space',
};

// ── Path stats ────────────────────────────────────────────────────────────────

interface PathStats {
  endingCount: number;
  shortestPath: number | null;
  longestPath: number | null;
}

function computePathStats(
  labelNodes: LabelNode[],
  routeLinks: RouteLink[],
): PathStats {
  if (labelNodes.length === 0) return { endingCount: 0, shortestPath: null, longestPath: null };

  // Outgoing adjacency list keyed by node id
  const outgoing = new Map<string, string[]>();
  labelNodes.forEach(n => outgoing.set(n.id, []));
  routeLinks.forEach(link => {
    outgoing.get(link.sourceId)?.push(link.targetId);
  });

  const deadEndIds = new Set(
    labelNodes.filter(n => (outgoing.get(n.id)?.length ?? 0) === 0).map(n => n.id),
  );

  const entryNode = labelNodes.find(n => n.label === 'start');
  if (!entryNode || deadEndIds.size === 0) {
    return { endingCount: deadEndIds.size, shortestPath: null, longestPath: null };
  }

  // BFS: shortest hop count from start to any dead-end
  let shortestPath: number | null = null;
  const bfsQueue: [string, number][] = [[entryNode.id, 0]];
  const bfsVisited = new Set<string>([entryNode.id]);
  while (bfsQueue.length > 0) {
    const [nodeId, depth] = bfsQueue.shift()!;
    if (deadEndIds.has(nodeId)) { shortestPath = depth; break; }
    for (const nextId of (outgoing.get(nodeId) ?? [])) {
      if (!bfsVisited.has(nextId)) {
        bfsVisited.add(nextId);
        bfsQueue.push([nextId, depth + 1]);
      }
    }
  }

  // DFS: longest simple path from start to any dead-end (cycle-safe via in-stack set).
  // Backtracking DFS is exponential on large graphs — cap at 200ms and return null if
  // the graph is too complex to solve in time (renders as '—' in the UI).
  let longestPath: number | null = null;
  let timedOut = false;
  const deadline = performance.now() + 200;
  const inStack = new Set<string>();

  function dfs(nodeId: string, depth: number) {
    if (timedOut) return;
    if (performance.now() > deadline) { timedOut = true; return; }
    if (inStack.has(nodeId)) return;
    if (deadEndIds.has(nodeId)) {
      if (longestPath === null || depth > longestPath) longestPath = depth;
      return;
    }
    inStack.add(nodeId);
    for (const nextId of (outgoing.get(nodeId) ?? [])) {
      dfs(nextId, depth + 1);
    }
    inStack.delete(nodeId);
  }

  dfs(entryNode.id, 0);

  return { endingCount: deadEndIds.size, shortestPath, longestPath: timedOut ? null : longestPath };
}

// ── Shared components ─────────────────────────────────────────────────────────

const InlineSpinner: React.FC = () => (
  <svg className="animate-spin h-5 w-5 text-indigo-400 inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
  </svg>
);

const SectionLabel: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2 className="text-xs font-semibold text-secondary uppercase tracking-widest mb-3">{children}</h2>
);

const StatCard: React.FC<{
  label: string;
  value: React.ReactNode;
  sub?: string;
  onClick?: () => void;
  testId?: string;
}> = ({ label, value, sub, onClick, testId }) => (
  <div
    className={`bg-secondary rounded-lg p-4 flex flex-col gap-1 ${onClick ? 'cursor-pointer hover:ring-1 hover:ring-indigo-400 transition-shadow' : ''}`}
    onClick={onClick}
    role={onClick ? 'button' : undefined}
    tabIndex={onClick ? 0 : undefined}
    onKeyDown={onClick ? (e) => { if (e.key === 'Enter' || e.key === ' ') onClick(); } : undefined}
    data-testid={testId}
  >
    <span className="text-xs font-semibold text-secondary uppercase tracking-wide">{label}</span>
    <span className="text-2xl font-bold text-primary">{value}</span>
    {sub && <span className="text-xs text-secondary">{sub}</span>}
  </div>
);

// ── Character table (used when > 6 characters) ────────────────────────────────

type SortKey = 'name' | 'words';
type SortDir = 'asc' | 'desc';

const CharacterTable: React.FC<{
  data: { name: string; words: number; color: string }[];
}> = ({ data }) => {
  const [sortKey, setSortKey] = useState<SortKey>('words');
  const [sortDir, setSortDir] = useState<SortDir>('desc');

  const totalDialogue = useMemo(() => data.reduce((s, d) => s + d.words, 0), [data]);

  const sorted = useMemo(() => {
    return [...data].sort((a, b) => {
      const mul = sortDir === 'asc' ? 1 : -1;
      if (sortKey === 'name') return mul * a.name.localeCompare(b.name);
      return mul * (a.words - b.words);
    });
  }, [data, sortKey, sortDir]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => (d === 'asc' ? 'desc' : 'asc'));
    else { setSortKey(key); setSortDir('desc'); }
  };

  const SortIcon: React.FC<{ col: SortKey }> = ({ col }) => (
    <span className={`ml-1 ${sortKey === col ? 'text-primary' : 'text-secondary opacity-40'}`}>
      {sortKey === col ? (sortDir === 'asc' ? '↑' : '↓') : '↕'}
    </span>
  );

  return (
    <div className="overflow-x-auto rounded-lg border border-primary">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-tertiary border-b border-primary text-secondary text-xs">
            <th className="px-3 py-2 w-8" />
            <th
              className="px-3 py-2 text-left font-semibold cursor-pointer select-none"
              onClick={() => toggleSort('name')}
            >
              Character <SortIcon col="name" />
            </th>
            <th
              className="px-3 py-2 text-right font-semibold cursor-pointer select-none"
              onClick={() => toggleSort('words')}
            >
              Words <SortIcon col="words" />
            </th>
            <th className="px-3 py-2 pr-4 text-right font-semibold">Share</th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((row, i) => {
            const share = totalDialogue > 0 ? (row.words / totalDialogue) * 100 : 0;
            return (
              <tr key={row.name} className={`border-b border-primary last:border-0 ${i % 2 === 1 ? 'bg-secondary/20' : ''}`}>
                <td className="px-3 py-2">
                  <span
                    className="inline-block w-3 h-3 rounded-full"
                    style={{ backgroundColor: row.color }}
                  />
                </td>
                <td className="px-3 py-2 font-medium text-primary">{row.name}</td>
                <td className="px-3 py-2 text-right tabular-nums text-secondary">
                  {row.words.toLocaleString()}
                </td>
                <td className="px-3 py-2 pr-4">
                  <div className="flex items-center justify-end gap-2">
                    <div className="w-20 h-1.5 bg-tertiary rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{ width: `${share}%`, backgroundColor: row.color }}
                      />
                    </div>
                    <span className="tabular-nums text-secondary text-xs w-10 text-right">
                      {share.toFixed(1)}%
                    </span>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

// ── Performance helpers ───────────────────────────────────────────────────────

import type { MemorySample } from '@/hooks/usePerformanceMetrics';

function formatMs(ms: number): string {
  return ms >= 1000 ? `${(ms / 1000).toFixed(2)} s` : `${Math.round(ms)} ms`;
}

const PerfStatCard: React.FC<{ label: string; valueMs: number | null; targetMs?: number }> = ({ label, valueMs, targetMs }) => {
  const met = targetMs !== null && targetMs !== undefined && valueMs !== null && valueMs <= targetMs;
  const exceeded = targetMs !== null && targetMs !== undefined && valueMs !== null && valueMs > targetMs;
  return (
    <div className="bg-secondary rounded-lg p-4 flex flex-col gap-1">
      <p className="text-xs text-secondary uppercase tracking-wide font-medium">{label}</p>
      <p className="text-2xl font-bold tabular-nums">
        {valueMs !== null ? formatMs(valueMs) : <span className="text-secondary text-base font-normal">—</span>}
      </p>
      {targetMs !== undefined && (
        <p className="text-xs">
          {valueMs === null
            ? <span className="text-secondary">target: {formatMs(targetMs)}</span>
            : met
              ? <span className="text-green-500">target {formatMs(targetMs)} ✓</span>
              : exceeded
                ? <span className="text-red-500">over target ({formatMs(targetMs)})</span>
                : null}
        </p>
      )}
      {targetMs === undefined && <p className="text-xs text-secondary">session latest</p>}
    </div>
  );
};

const MemorySparkline: React.FC<{ samples: MemorySample[] }> = ({ samples }) => {
  const W = 400;
  const H = 48;
  const min = Math.min(...samples.map(s => s.mb));
  const max = Math.max(...samples.map(s => s.mb));
  const range = Math.max(max - min, 1);
  const pts = samples.map((s, i) => {
    const x = (i / (samples.length - 1)) * W;
    const y = H - ((s.mb - min) / range) * (H - 4) - 2;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-12" preserveAspectRatio="none">
      <polyline points={pts} fill="none" stroke="#6366f1" strokeWidth="1.5" strokeLinejoin="round" />
    </svg>
  );
};

// ── File limit toggle ─────────────────────────────────────────────────────────

const FILE_LIMITS = [15, 30, 'all'] as const;
type FileLimit = typeof FILE_LIMITS[number];

const CHAR_LIMITS = [5, 15, 'all'] as const;
type CharLimit = typeof CHAR_LIMITS[number];

// ── Main component ────────────────────────────────────────────────────────────

const StatsView: React.FC<StatsViewProps> = ({
  blocks,
  analysisResult,
  routeAnalysisResult,
  projectImages,
  imageMetadata,
  projectAudios,
  diagnosticsErrorCount,
  onOpenDiagnostics,
  onOpenEditor,
  performanceMetrics,
}) => {
  const fps = useCanvasFps(!!performanceMetrics);
  const [fileLimit, setFileLimit] = useState<FileLimit>(15);
  const [charLimit, setCharLimit] = useState<CharLimit>(5);
  const [coverageTypeFilter, setCoverageTypeFilter] = useState<CoverageTypeFilter>('all');
  const [coverageStatusFilter, setCoverageStatusFilter] = useState<CoverageStatusFilter>('all');
  const [coverageTextFilter, setCoverageTextFilter] = useState('');
  const [coverageSortKey, setCoverageSortKey] = useState<CoverageSortKey>('status');
  const [coverageSortDir, setCoverageSortDir] = useState<CoverageSortDir>('asc');
  const [varCoverageStatusFilter, setVarCoverageStatusFilter] = useState<VariableCoverageStatusFilter>('all');
  const [varCoverageTextFilter, setVarCoverageTextFilter] = useState('');
  const [varCoverageSortKey, setVarCoverageSortKey] = useState<VariableCoverageSortKey>('name');
  const [varCoverageSortDir, setVarCoverageSortDir] = useState<VariableCoverageSortDir>('asc');
  const [expandedVarNames, setExpandedVarNames] = useState<Set<string>>(new Set());

  const { branchingBlockIds, labels, characters, dialogueLines, variables, variableUsages } = analysisResult;
  const { identifiedRoutes, labelNodes, routeLinks, routesTruncated } = routeAnalysisResult;

  // BFS from the 'start' label to find all transitively unreachable labels.
  const unreachableLabels = useMemo(() => {
    const entryId = labelNodes.find(n => n.label === 'start')?.id;
    if (!entryId) return [] as LabelNode[];
    const outgoing = new Map<string, string[]>();
    routeLinks.forEach(l => {
      const targets = outgoing.get(l.sourceId) ?? [];
      targets.push(l.targetId);
      outgoing.set(l.sourceId, targets);
    });
    const reachable = new Set<string>();
    const queue = [entryId];
    while (queue.length > 0) {
      const curr = queue.shift()!;
      if (reachable.has(curr)) continue;
      reachable.add(curr);
      (outgoing.get(curr) ?? []).forEach(t => { if (!reachable.has(t)) queue.push(t); });
    }
    return labelNodes.filter(n => !reachable.has(n.id)).sort((a, b) => a.label.localeCompare(b.label));
  }, [labelNodes, routeLinks]);

  const [totalWords, setTotalWords] = useState<number | null>(null);
  useEffect(() => {
    setTotalWords(null);
    const id = setTimeout(() => {
      setTotalWords(blocks.reduce((acc, b) => acc + countWordsInScript(b.content), 0));
    }, 0);
    return () => clearTimeout(id);
  }, [blocks]);

  const [characterWordCounts, setCharacterWordCounts] = useState<Map<string, number> | null>(null);
  useEffect(() => {
    setCharacterWordCounts(null);
    const id = setTimeout(() => {
      const counts = new Map<string, number>();
      const DIALOGUE_RE = /(?:[a-zA-Z0-9_]+\s)?"((?:\\.|[^"\\])*)"/;
      dialogueLines.forEach((lines, blockId) => {
        const block = blocks.find(b => b.id === blockId);
        if (!block) return;
        const scriptLines = block.content.split('\n');
        lines.forEach(dl => {
          // dl.line is 1-based (matches Monaco's line numbering); scriptLines is 0-indexed.
          const rawLine = scriptLines[dl.line - 1] ?? '';
          const m = rawLine.match(DIALOGUE_RE);
          if (!m) return;
          const wordCount = m[1].trim().split(/\s+/).filter(Boolean).length;
          const tag = dl.tag || 'narrator';
          counts.set(tag, (counts.get(tag) ?? 0) + wordCount);
        });
      });
      setCharacterWordCounts(counts);
    }, 0);
    return () => clearTimeout(id);
  }, [blocks, dialogueLines]);

  const { dialogueWords, narrationWords } = useMemo(() => {
    if (!characterWordCounts) return { dialogueWords: null, narrationWords: null };
    let dialogue = 0;
    let narration = 0;
    characterWordCounts.forEach((words, tag) => {
      if (tag === 'narrator') narration += words;
      else dialogue += words;
    });
    return { dialogueWords: dialogue, narrationWords: narration };
  }, [characterWordCounts]);

  const labelCount = useMemo(() => Object.keys(labels).length, [labels]);

  const variableStats = useMemo(() => {
    let persistent = 0;
    let defaulted = 0;
    let implicit = 0;
    let constants = 0;
    let total = 0;
    variables.forEach(v => {
      // Python-block functions aren't save-persistence variables — exclude them
      // from these stats, which are about define/default/implicit variable usage.
      if (v.type === 'function') return;
      total++;
      if (v.name.startsWith('persistent.')) {
        persistent++;
      } else if (v.type === 'define') {
        constants++;
      } else if (v.type === 'implicit') {
        implicit++;
      } else {
        defaulted++;
      }
    });
    return { total, persistent, defaulted, implicit, constants };
  }, [variables]);

  const undefinedVariableCount = useMemo(() => {
    const known = buildKnownIdentifierSet(analysisResult);
    const seen = new Set<string>();
    blocks.forEach(block => {
      if (!block.content) return;
      extractUndefinedVariableReferences(block.content, known).forEach(ref => seen.add(ref.name));
    });
    return seen.size;
  }, [blocks, analysisResult]);

  const topVariables = useMemo(() => {
    const rows: { name: string; usages: number; type: string }[] = [];
    variables.forEach((v, name) => {
      const usages = variableUsages.get(name)?.length ?? 0;
      rows.push({ name, usages, type: v.type });
    });
    return rows.sort((a, b) => b.usages - a.usages).slice(0, 10);
  }, [variables, variableUsages]);

  const variableCoverageRows = useMemo(() => {
    const rows: VariableCoverageRow[] = [];
    variables.forEach((v, name) => {
      // Limit to story blocks to avoid false positives on GUI/config variables
      // that Ren'Py may consume internally without explicit code references
      // (matches useDiagnostics.ts's unused-variable check).
      if (!analysisResult.storyBlockIds.has(v.definedInBlockId)) return;
      const usages = variableUsages.get(name) ?? [];
      const locations = groupUsageLocations(usages, blocks, analysisResult.labelNodes);
      rows.push({ name, type: v.type, status: usages.length > 0 ? 'referenced' : 'unreferenced', locations });
    });
    return rows;
  }, [variables, variableUsages, blocks, analysisResult.labelNodes, analysisResult.storyBlockIds]);

  const filteredVariableCoverageRows = useMemo(() => {
    let list = variableCoverageRows;
    if (varCoverageStatusFilter !== 'all') list = list.filter(r => r.status === varCoverageStatusFilter);
    if (varCoverageTextFilter) {
      const lower = varCoverageTextFilter.toLowerCase();
      list = list.filter(r => r.name.toLowerCase().includes(lower));
    }
    return [...list].sort((a, b) => {
      const mul = varCoverageSortDir === 'asc' ? 1 : -1;
      if (varCoverageSortKey === 'name') return mul * a.name.localeCompare(b.name);
      const statusOrder = { referenced: 0, unreferenced: 1 };
      return mul * (statusOrder[a.status] - statusOrder[b.status]);
    });
  }, [variableCoverageRows, varCoverageStatusFilter, varCoverageTextFilter, varCoverageSortKey, varCoverageSortDir]);

  function toggleVarCoverageSort(key: VariableCoverageSortKey) {
    if (varCoverageSortKey === key) setVarCoverageSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setVarCoverageSortKey(key); setVarCoverageSortDir('asc'); }
  }

  function toggleVarExpanded(name: string) {
    setExpandedVarNames(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name); else next.add(name);
      return next;
    });
  }

  const complexity = useMemo(
    () => getComplexityBucket(branchingBlockIds.size, blocks.length, identifiedRoutes.length),
    [branchingBlockIds.size, blocks.length, identifiedRoutes.length],
  );

  const [pathStats, setPathStats] = useState<PathStats | null>(null);
  useEffect(() => {
    setPathStats(null);
    const id = setTimeout(() => {
      setPathStats(computePathStats(labelNodes, routeLinks));
    }, 0);
    return () => clearTimeout(id);
  }, [labelNodes, routeLinks]);

  const charChartData = useMemo(() => {
    if (!characterWordCounts) return null;
    const data: { name: string; words: number; color: string }[] = [];
    characterWordCounts.forEach((words, tag) => {
      const char = characters.get(tag);
      data.push({ name: char?.name || tag, words, color: char?.color || '#6366f1' });
    });
    return data.sort((a, b) => b.words - a.words);
  }, [characterWordCounts, characters]);

  const displayedChars = useMemo(
    () => !charChartData ? null : charLimit === 'all' ? charChartData : charChartData.slice(0, charLimit),
    [charChartData, charLimit],
  );

  const lineChartData = useMemo(() => {
    const all = blocks
      .map(b => ({
        name: b.title || b.filePath?.split('/').pop() || 'Untitled',
        lines: b.content.split('\n').length,
      }))
      .sort((a, b) => b.lines - a.lines);
    return fileLimit === 'all' ? all : all.slice(0, fileLimit);
  }, [blocks, fileLimit]);

  // ── Coverage computation ────────────────────────────────────────────────────

  type CoverageData = {
    rows: CoverageRow[];
    imageTotal: number; imageReferenced: number; imageMissing: number; imageOrphaned: number;
    audioTotal: number; audioReferenced: number; audioMissing: number; audioOrphaned: number;
  };

  const [coverageData, setCoverageData] = useState<CoverageData | null>(null);
  useEffect(() => {
    setCoverageData(null);
    const id = setTimeout(() => {
    const _computeCoverage = () => {
    // Collect all image tags and audio paths referenced in code
    const referencedImageTags = new Set<string>();
    const referencedAudioPaths = new Set<string>();

    for (const block of blocks) {
      if (!block.content) continue;
      for (const line of block.content.split('\n')) {
        const showMatch = line.match(/^\s*(?:show|scene)\s+([a-zA-Z0-9_ ]+)/);
        if (showMatch) {
          const rawTag = showMatch[1].trim();
          if (!['expression', 'layer', 'screen'].includes(rawTag.split(' ')[0])) {
            referencedImageTags.add(rawTag);
          }
        }
        const audioMatch = line.match(/^\s*(?:play|queue)\s+\w+\s+(.+)/);
        if (audioMatch) {
          const content = audioMatch[1].trim();
          const quotedMatch = content.match(/^["']([^"']+)["']/);
          if (quotedMatch) {
            referencedAudioPaths.add(quotedMatch[1]);
          } else {
            const firstToken = content.split(/\s+/)[0];
            if (firstToken !== 'expression') referencedAudioPaths.add(firstToken);
          }
        }
      }
    }

    // Build canonical image name → ProjectImage map
    const imageByName = new Map<string, ProjectImage>();
    // All known tags (name + fullTag) for prefix-matching
    const knownImageNames = new Set<string>();

    projectImages.forEach(img => {
      const meta = imageMetadata.get(img.projectFilePath || img.filePath);
      const name = meta?.renpyName || img.fileName.split('.').slice(0, -1).join('.');
      imageByName.set(name, img);
      knownImageNames.add(name);
      if (meta?.tags?.length) {
        knownImageNames.add(`${name} ${meta.tags.join(' ')}`.trim());
      }
    });
    // Also include image X definitions from code
    analysisResult.definedImages.forEach(tag => knownImageNames.add(tag));

    // Determine which canonical image names are referenced
    const referencedImageNames = new Set<string>();
    referencedImageTags.forEach(refTag => {
      // A projectImage with `name` is referenced if refTag === name or starts with name + ' '
      imageByName.forEach((_, name) => {
        if (refTag === name || refTag.startsWith(name + ' ')) {
          referencedImageNames.add(name);
        }
      });
      // Also cover `image X Y` defines that aren't projectImages
      knownImageNames.forEach(knownTag => {
        if (refTag === knownTag || refTag.startsWith(knownTag + ' ')) {
          // mark as "covered" so we don't emit a missing row for refTag
        }
      });
    });

    const rows: CoverageRow[] = [];

    // Rows for project images (referenced or orphaned)
    imageByName.forEach((img, name) => {
      rows.push({
        id: `image:${img.filePath}`,
        name,
        type: 'image',
        status: referencedImageNames.has(name) ? 'referenced' : 'orphaned',
      });
    });

    // Rows for missing images (referenced in code but no project file / define)
    referencedImageTags.forEach(refTag => {
      // Check if covered by any known image name (prefix match)
      const parts = refTag.split(' ');
      let covered = false;
      for (let i = 1; i <= parts.length; i++) {
        if (knownImageNames.has(parts.slice(0, i).join(' '))) { covered = true; break; }
      }
      if (!covered) {
        rows.push({ id: `missing-image:${refTag}`, name: refTag, type: 'image', status: 'missing' });
      }
    });

    // Build audio lookup: all path/name variants → RenpyAudio
    const audioByKey = new Map<string, RenpyAudio>();
    projectAudios.forEach(aud => {
      audioByKey.set(aud.fileName, aud);
      const noExt = aud.fileName.split('.').slice(0, -1).join('.');
      if (noExt) audioByKey.set(noExt, aud);
      if (aud.projectFilePath) audioByKey.set(aud.projectFilePath.replace(/\\/g, '/'), aud);
      if (aud.filePath) audioByKey.set(aud.filePath.replace(/\\/g, '/'), aud);
    });

    // Determine which audio files are referenced
    const referencedAudioFileNames = new Set<string>();
    const missingAudioPaths: string[] = [];
    referencedAudioPaths.forEach(refPath => {
      let found = false;
      audioByKey.forEach((aud, key) => {
        if (key.endsWith(refPath) || refPath.endsWith(key)) {
          found = true;
          referencedAudioFileNames.add(aud.fileName);
        }
      });
      if (!found) missingAudioPaths.push(refPath);
    });

    // Rows for project audio
    const seenAudioFiles = new Set<string>();
    projectAudios.forEach(aud => {
      if (seenAudioFiles.has(aud.fileName)) return;
      seenAudioFiles.add(aud.fileName);
      rows.push({
        id: `audio:${aud.filePath}`,
        name: aud.fileName,
        type: 'audio',
        status: referencedAudioFileNames.has(aud.fileName) ? 'referenced' : 'orphaned',
      });
    });

    // Rows for missing audio
    missingAudioPaths.forEach(refPath => {
      rows.push({ id: `missing-audio:${refPath}`, name: refPath, type: 'audio', status: 'missing' });
    });

    const imageRows = rows.filter(r => r.type === 'image');
    const audioRows = rows.filter(r => r.type === 'audio');

    return {
      rows,
      imageTotal: imageRows.length,
      imageReferenced: imageRows.filter(r => r.status === 'referenced').length,
      imageMissing: imageRows.filter(r => r.status === 'missing').length,
      imageOrphaned: imageRows.filter(r => r.status === 'orphaned').length,
      audioTotal: audioRows.length,
      audioReferenced: audioRows.filter(r => r.status === 'referenced').length,
      audioMissing: audioRows.filter(r => r.status === 'missing').length,
      audioOrphaned: audioRows.filter(r => r.status === 'orphaned').length,
    };
    };
    setCoverageData(_computeCoverage());
    }, 0);
    return () => clearTimeout(id);
   
  }, [blocks, projectImages, imageMetadata, projectAudios, analysisResult.definedImages]);

  const coverageRows = useMemo(() => {
    if (!coverageData) return null;
    let list = coverageData.rows;
    if (coverageTypeFilter !== 'all') list = list.filter(r => r.type === coverageTypeFilter);
    if (coverageStatusFilter !== 'all') list = list.filter(r => r.status === coverageStatusFilter);
    if (coverageTextFilter) {
      const lower = coverageTextFilter.toLowerCase();
      list = list.filter(r => r.name.toLowerCase().includes(lower));
    }
    return [...list].sort((a, b) => {
      const mul = coverageSortDir === 'asc' ? 1 : -1;
      if (coverageSortKey === 'name') return mul * a.name.localeCompare(b.name);
      if (coverageSortKey === 'type') return mul * a.type.localeCompare(b.type);
      // status: referenced < orphaned < missing (most urgent last)
      const statusOrder = { referenced: 0, orphaned: 1, missing: 2 };
      return mul * (statusOrder[a.status] - statusOrder[b.status]);
    });
  }, [coverageData, coverageTypeFilter, coverageStatusFilter, coverageTextFilter, coverageSortKey, coverageSortDir]);

  function toggleCoverageSort(key: CoverageSortKey) {
    if (coverageSortKey === key) setCoverageSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setCoverageSortKey(key); setCoverageSortDir('asc'); }
  }

  if (blocks.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-secondary gap-3">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 opacity-30" viewBox="0 0 20 20" fill="currentColor">
          <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zm6-4a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zm6-3a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
        </svg>
        <p className="text-lg font-medium">No script loaded yet</p>
        <p className="text-sm">Open a project to see statistics.</p>
      </div>
    );
  }

  const estimatedMinutes = totalWords !== null ? Math.round(totalWords / 200) : null;
  const branchRatioPercent = Math.round((branchingBlockIds.size / Math.max(1, blocks.length)) * 100);

  const statsReportData: StatsReportData = {
    totalWords,
    estimatedMinutes,
    dialogueWords,
    narrationWords,
    scriptFiles: blocks.length,
    totalCharacters: characters.size,
    speakingCharacters: charChartData?.length ?? null,
    labelCount,
    branchingFiles: branchingBlockIds.size,
    identifiedRoutes: identifiedRoutes.length,
    routesTruncated,
    unreachableLabels: unreachableLabels.length,
    complexity,
    distinctEndings: pathStats?.endingCount ?? null,
    shortestPath: pathStats?.shortestPath ?? null,
    longestPath: pathStats?.longestPath ?? null,
    imageAssets: projectImages.size,
    imageReferenced: coverageData?.imageReferenced ?? null,
    audioAssets: projectAudios.size,
    audioReferenced: coverageData?.audioReferenced ?? null,
    scriptErrors: diagnosticsErrorCount,
    characterWordCounts: charChartData?.map(c => ({ name: c.name, words: c.words })) ?? null,
    assetIssues: (coverageData?.rows ?? [])
      .filter((r): r is typeof r & { status: 'missing' | 'orphaned' } => r.status === 'missing' || r.status === 'orphaned')
      .map(r => ({ name: r.name, type: r.type, status: r.status })),
  };

  return (
    <div className="h-full overflow-y-auto p-6 text-primary">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Script Statistics</h1>
        <ExportMenu
          filenameBase="script-statistics"
          getMarkdown={() => statsToMarkdown(statsReportData)}
          getCSV={() => statsToCSV(statsReportData)}
        />
      </div>

      {/* Writing */}
      <SectionLabel>Writing</SectionLabel>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <StatCard
          label="Total Words"
          value={totalWords === null ? <InlineSpinner /> : totalWords.toLocaleString()}
          sub="dialogue & narration"
        />
        <StatCard
          label="Estimated Playtime"
          value={
            estimatedMinutes === null ? <InlineSpinner /> :
            estimatedMinutes < 60
              ? `${estimatedMinutes} min`
              : `${Math.floor(estimatedMinutes / 60)}h ${estimatedMinutes % 60}m`
          }
          sub="at 200 words/min"
        />
        <StatCard
          label="Dialogue Words"
          value={dialogueWords === null ? <InlineSpinner /> : dialogueWords.toLocaleString()}
          sub={totalWords !== null && totalWords > 0 && dialogueWords !== null ? `${Math.round((dialogueWords / totalWords) * 100)}% of total` : 'characters speaking'}
        />
        <StatCard
          label="Narration Words"
          value={narrationWords === null ? <InlineSpinner /> : narrationWords.toLocaleString()}
          sub={totalWords !== null && totalWords > 0 && narrationWords !== null ? `${Math.round((narrationWords / totalWords) * 100)}% of total` : 'narrator lines'}
        />
      </div>

      {/* Structure */}
      <SectionLabel>Structure</SectionLabel>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-4">
        <StatCard
          label="Script Files"
          value={blocks.length.toLocaleString()}
          sub=".rpy files"
        />
        <StatCard
          label="Characters"
          value={characters.size.toLocaleString()}
          sub={charChartData !== null ? `${charChartData.length} speaking` : '…'}
        />
        <StatCard
          label="Labels"
          value={labelCount.toLocaleString()}
          sub="named script points"
        />
        <StatCard
          label="Menus / Branches"
          value={branchingBlockIds.size.toLocaleString()}
          sub="files with choices"
        />
        <StatCard
          label="Identified Routes"
          value={`${identifiedRoutes.length.toLocaleString()}${routesTruncated ? '+' : ''}`}
          sub={routesTruncated ? 'unique story paths (limit reached)' : 'unique story paths'}
        />
        <StatCard
          label="Unreachable Labels"
          value={unreachableLabels.length > 0
            ? <span className="text-orange-500 dark:text-orange-400">{unreachableLabels.length.toLocaleString()}</span>
            : <span className="text-green-500">0</span>
          }
          sub="not reachable from start"
        />
      </div>

      {/* Unreachable Labels detail */}
      {unreachableLabels.length > 0 && (
        <div className="mb-8 overflow-x-auto rounded-lg border border-orange-200 dark:border-orange-800">
          <table className="w-full text-sm">
            <caption className="text-xs font-semibold text-orange-600 dark:text-orange-400 uppercase tracking-widest text-left px-3 py-2 bg-orange-50 dark:bg-orange-950/30 border-b border-orange-200 dark:border-orange-800">
              Unreachable Labels — no path from &ldquo;start&rdquo; leads here
            </caption>
            <thead>
              <tr className="bg-orange-50/60 dark:bg-orange-950/20 border-b border-orange-200 dark:border-orange-800 text-secondary text-xs">
                <th className="px-3 py-2 text-left font-semibold">Label</th>
                <th className="px-3 py-2 text-left font-semibold">File</th>
                <th className="px-3 py-2 text-left font-semibold w-20">Line</th>
                {onOpenEditor && <th className="px-3 py-2 w-10" />}
              </tr>
            </thead>
            <tbody>
              {unreachableLabels.map((node, i) => {
                const block = blocks.find(b => b.id === node.blockId);
                const fileName = block?.filePath.split(/[/\\]/).pop() ?? node.blockId;
                return (
                  <tr
                    key={node.id}
                    className={`border-b border-orange-100 dark:border-orange-900 last:border-0 ${i % 2 === 1 ? 'bg-secondary/20' : ''} ${onOpenEditor ? 'cursor-pointer hover:bg-orange-50 dark:hover:bg-orange-950/30 group' : ''}`}
                    onClick={onOpenEditor ? () => onOpenEditor(node.blockId, node.startLine) : undefined}
                    onKeyDown={onOpenEditor ? (e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        onOpenEditor(node.blockId, node.startLine);
                      }
                    } : undefined}
                    tabIndex={onOpenEditor ? 0 : undefined}
                    role={onOpenEditor ? 'button' : undefined}
                    title={onOpenEditor ? `Open "${node.label}" in editor` : undefined}
                  >
                    <td className="px-3 py-2 font-mono text-xs text-primary">{node.label}</td>
                    <td className="px-3 py-2 text-xs text-secondary truncate max-w-[200px]" title={block?.filePath}>{fileName}</td>
                    <td className="px-3 py-2 text-xs text-secondary tabular-nums">{node.startLine + 1}</td>
                    {onOpenEditor && (
                      <td className="px-3 py-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 text-orange-400 opacity-0 group-hover:opacity-100 transition-opacity" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 101.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z" />
                          <path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z" />
                        </svg>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Variables */}
      {(variableStats.total > 0 || undefinedVariableCount > 0) && (<>
        <SectionLabel>Variables</SectionLabel>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <StatCard
            label="Total Variables"
            value={variableStats.total.toLocaleString()}
            sub="across all script files"
          />
          <StatCard
            label="Persistent"
            value={variableStats.persistent.toLocaleString()}
            sub="saved between sessions"
          />
          <StatCard
            label="Default"
            value={variableStats.defaulted.toLocaleString()}
            sub="default statements"
          />
          <StatCard
            label="Implicit"
            value={variableStats.implicit.toLocaleString()}
            sub="$ assignments, not real defaults"
          />
          <StatCard
            label="Constants"
            value={variableStats.constants.toLocaleString()}
            sub="define statements"
          />
          <StatCard
            label="Undefined Variables"
            value={undefinedVariableCount.toLocaleString()}
            sub="referenced but never defined"
            testId="stat-undefined-variables"
          />
        </div>
        {topVariables.length > 0 && (
          <div className="mb-8 overflow-x-auto rounded-lg border border-primary">
            <table className="w-full text-sm">
              <caption className="text-xs font-semibold text-secondary uppercase tracking-widest text-left px-3 py-2 bg-tertiary border-b border-primary">Top 10 Variables</caption>
              <thead>
                <tr className="bg-tertiary border-b border-primary text-secondary text-xs">
                  <th className="px-3 py-2 text-left font-semibold">Variable</th>
                  <th className="px-3 py-2 text-left font-semibold w-24">Type</th>
                  <th className="px-3 py-2 text-right font-semibold w-24">Usages</th>
                </tr>
              </thead>
              <tbody>
                {topVariables.map((row, i) => (
                  <tr key={row.name} className={`border-b border-primary last:border-0 ${i % 2 === 1 ? 'bg-secondary/20' : ''}`}>
                    <td className="px-3 py-2 font-mono text-xs text-primary">{row.name}</td>
                    <td className="px-3 py-2 text-xs text-secondary capitalize">{row.type}</td>
                    <td className="px-3 py-2 text-right tabular-nums text-secondary text-xs">{row.usages}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </>)}

      {/* Complexity banner */}
      <div className="mb-8 bg-secondary rounded-lg p-4 flex items-center gap-4">
        <span
          className="text-sm font-bold px-3 py-1.5 rounded-full text-white flex-shrink-0"
          style={{ backgroundColor: COMPLEXITY_COLORS[complexity] }}
        >
          {complexity}
        </span>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-primary">Story Complexity</p>
          <p className="text-xs text-secondary">{COMPLEXITY_DESCRIPTIONS[complexity]}</p>
        </div>
        <div className="ml-auto text-right text-xs text-secondary flex-shrink-0">
          <p>{branchRatioPercent}% of files branch</p>
          <p>{identifiedRoutes.length}{routesTruncated ? '+' : ''} route{identifiedRoutes.length !== 1 ? 's' : ''} identified</p>
        </div>
      </div>

      {/* Endings & Completeness */}
      <SectionLabel>Endings &amp; Completeness</SectionLabel>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        <StatCard
          label="Distinct Endings"
          value={pathStats === null ? <InlineSpinner /> : pathStats.endingCount.toLocaleString()}
          sub="labels with no exit"
        />
        <StatCard
          label="Shortest Path"
          value={pathStats === null ? <InlineSpinner /> : (pathStats.shortestPath !== null ? `${pathStats.shortestPath} steps` : '—')}
          sub="from start to first ending"
        />
        <StatCard
          label="Longest Path"
          value={pathStats === null ? <InlineSpinner /> : (pathStats.longestPath !== null ? `${pathStats.longestPath} steps` : '—')}
          sub="from start to deepest ending"
        />
      </div>

      {/* Assets & Health */}
      <SectionLabel>Assets &amp; Health</SectionLabel>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        <StatCard
          label="Image Assets"
          value={projectImages.size.toLocaleString()}
          sub={coverageData !== null && coverageData.imageReferenced > 0 ? `${coverageData.imageReferenced} referenced` : 'tracked images'}
        />
        <StatCard
          label="Audio Assets"
          value={projectAudios.size.toLocaleString()}
          sub={coverageData !== null && coverageData.audioReferenced > 0 ? `${coverageData.audioReferenced} referenced` : 'tracked audio files'}
        />
        <StatCard
          label={diagnosticsErrorCount > 0 ? 'Script Errors' : 'No Errors'}
          value={
            diagnosticsErrorCount > 0
              ? <span className="text-red-500">{diagnosticsErrorCount}</span>
              : <span className="text-green-500">✓</span>
          }
          sub={diagnosticsErrorCount > 0 ? 'open Diagnostics tab →' : 'project looks clean'}
          onClick={diagnosticsErrorCount > 0 ? onOpenDiagnostics : undefined}
        />
      </div>

      {/* Word count by character */}
      <section className="mb-8">
        <h2 className="text-lg font-semibold mb-3">Word Count by Character</h2>
        {!charChartData || !displayedChars ? (
          <div className="flex items-center gap-2 text-secondary text-sm py-4">
            <InlineSpinner /> <span>Computing character word counts…</span>
          </div>
        ) : charChartData.length === 0 ? null : (
          <>
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-1">
              {CHAR_LIMITS.map(l => (
                <button
                  key={String(l)}
                  onClick={() => setCharLimit(l)}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                    charLimit === l
                      ? 'bg-indigo-600 text-white'
                      : 'bg-tertiary text-secondary hover:bg-tertiary-hover'
                  }`}
                >
                  {l === 'all' ? 'All' : `Top ${l}`}
                </button>
              ))}
            </div>
          </div>
          <p className="text-xs text-secondary mb-3">
            Showing {displayedChars.length} of {charChartData.length} speaking character{charChartData.length !== 1 ? 's' : ''}
            {characters.size > charChartData.length && ` (${characters.size - charChartData.length} defined with no dialogue)`}
          </p>
          {displayedChars.length > 6 ? (
            <CharacterTable data={displayedChars} />
          ) : (
            <ResponsiveContainer width="100%" height={Math.max(160, displayedChars.length * 40)}>
              <BarChart
                data={displayedChars}
                layout="vertical"
                margin={{ top: 4, right: 16, left: 8, bottom: 4 }}
              >
                <CartesianGrid strokeDasharray="3 3" className="stroke-primary opacity-20" />
                <XAxis type="number" tick={{ fontSize: 12 }} />
                <YAxis type="category" dataKey="name" width={130} tick={{ fontSize: 12 }} />
                <Tooltip formatter={(value: number) => [value.toLocaleString(), 'Words']} />
                <Bar dataKey="words" radius={[0, 4, 4, 0]}>
                  {displayedChars.map((entry, index) => (
                    <Cell key={index} fill={entry.color || '#6366f1'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
          </>
        )}
      </section>

      {/* Lines by file */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold">Lines of Script by File</h2>
          <div className="flex items-center gap-1">
            {FILE_LIMITS.map(l => (
              <button
                key={String(l)}
                onClick={() => setFileLimit(l)}
                className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                  fileLimit === l
                    ? 'bg-indigo-600 text-white'
                    : 'bg-tertiary text-secondary hover:bg-tertiary-hover'
                }`}
              >
                {l === 'all' ? 'All' : `Top ${l}`}
              </button>
            ))}
          </div>
        </div>
        {fileLimit !== 'all' && blocks.length > fileLimit && (
          <p className="text-xs text-secondary mb-2">
            Showing {fileLimit} of {blocks.length} files by line count
          </p>
        )}
        <ResponsiveContainer width="100%" height={Math.max(200, lineChartData.length * 28)}>
          <BarChart
            data={lineChartData}
            layout="vertical"
            margin={{ top: 4, right: 16, left: 8, bottom: 4 }}
          >
            <CartesianGrid strokeDasharray="3 3" className="stroke-primary opacity-20" />
            <XAxis type="number" tick={{ fontSize: 12 }} />
            <YAxis type="category" dataKey="name" width={160} tick={{ fontSize: 11 }} />
            <Tooltip formatter={(value: number) => [value.toLocaleString(), 'Lines']} />
            <Bar dataKey="lines" fill="#6366f1" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </section>

      {/* Asset Coverage */}
      <section className="mb-8">
        <h2 className="text-lg font-semibold mb-3">Asset Coverage</h2>
        {!coverageData || !coverageRows ? (
          <div className="flex items-center gap-2 text-secondary text-sm py-4">
            <InlineSpinner /> <span>Scanning asset coverage…</span>
          </div>
        ) : coverageData.rows.length === 0 ? null : (<>

          {/* Coverage bars */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
            {[
              {
                label: 'Images',
                referenced: coverageData.imageReferenced,
                total: coverageData.imageTotal,
                missing: coverageData.imageMissing,
                orphaned: coverageData.imageOrphaned,
              },
              {
                label: 'Audio',
                referenced: coverageData.audioReferenced,
                total: coverageData.audioTotal,
                missing: coverageData.audioMissing,
                orphaned: coverageData.audioOrphaned,
              },
            ].map(({ label, referenced, total, missing, orphaned }) => {
              const pct = total > 0 ? Math.round((referenced / total) * 100) : 0;
              return (
                <div key={label} className="bg-secondary rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-primary">{label}</span>
                    <span className="text-xs text-secondary tabular-nums">{referenced}/{total} referenced ({pct}%)</span>
                  </div>
                  <div className="h-2 bg-tertiary rounded-full overflow-hidden mb-2">
                    <div
                      className="h-full bg-indigo-500 rounded-full transition-all"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="flex items-center gap-3 text-xs text-secondary">
                    {missing > 0 && (
                      <span className="text-orange-500 font-medium">{missing} missing from disk</span>
                    )}
                    {orphaned > 0 && (
                      <span className="text-gray-400">{orphaned} unreferenced</span>
                    )}
                    {missing === 0 && orphaned === 0 && (
                      <span className="text-green-500">All files accounted for</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2 mb-3">
            {/* Type pills */}
            <div className="flex rounded-md border border-primary overflow-hidden text-xs flex-none">
              {(['all', 'image', 'audio'] as CoverageTypeFilter[]).map(t => (
                <button
                  key={t}
                  onClick={() => setCoverageTypeFilter(t)}
                  aria-pressed={coverageTypeFilter === t}
                  className={`px-2.5 py-1 capitalize border-r border-primary last:border-0 transition-colors ${coverageTypeFilter === t ? 'bg-indigo-500 text-white' : 'bg-secondary text-secondary hover:bg-tertiary'}`}
                >
                  {t === 'all' ? 'All Types' : t === 'image' ? 'Images' : 'Audio'}
                </button>
              ))}
            </div>
            {/* Status pills */}
            <div className="flex rounded-md border border-primary overflow-hidden text-xs flex-none">
              {(['all', 'referenced', 'missing', 'orphaned'] as CoverageStatusFilter[]).map(s => (
                <button
                  key={s}
                  onClick={() => setCoverageStatusFilter(s)}
                  aria-pressed={coverageStatusFilter === s}
                  className={`px-2.5 py-1 capitalize border-r border-primary last:border-0 transition-colors ${coverageStatusFilter === s ? 'bg-indigo-500 text-white' : 'bg-secondary text-secondary hover:bg-tertiary'}`}
                >
                  {s === 'all' ? 'All Status' : s}
                </button>
              ))}
            </div>
            {/* Text search */}
            <div className="relative flex-1 min-w-[140px]">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Filter assets…"
                value={coverageTextFilter}
                onChange={e => setCoverageTextFilter(e.target.value)}
                className="w-full pl-7 pr-2 py-1 text-xs bg-secondary border border-primary rounded focus:outline-none focus:ring-1 focus:ring-indigo-400 text-primary placeholder:text-secondary"
              />
            </div>
            <span className="text-xs text-secondary flex-none">{coverageRows.length} asset{coverageRows.length !== 1 ? 's' : ''}</span>
          </div>

          {/* Coverage table */}
          <div className="overflow-x-auto rounded-lg border border-primary">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-tertiary border-b border-primary text-secondary text-xs">
                  <th
                    className="px-3 py-2 text-left font-semibold cursor-pointer select-none"
                    onClick={() => toggleCoverageSort('name')}
                  >
                    Asset {coverageSortKey === 'name' ? (coverageSortDir === 'asc' ? '↑' : '↓') : <span className="opacity-40">↕</span>}
                  </th>
                  <th
                    className="px-3 py-2 text-left font-semibold cursor-pointer select-none w-20"
                    onClick={() => toggleCoverageSort('type')}
                  >
                    Type {coverageSortKey === 'type' ? (coverageSortDir === 'asc' ? '↑' : '↓') : <span className="opacity-40">↕</span>}
                  </th>
                  <th
                    className="px-3 py-2 text-left font-semibold cursor-pointer select-none w-36"
                    onClick={() => toggleCoverageSort('status')}
                  >
                    Status {coverageSortKey === 'status' ? (coverageSortDir === 'asc' ? '↑' : '↓') : <span className="opacity-40">↕</span>}
                  </th>
                </tr>
              </thead>
              <tbody>
                {coverageRows.length === 0 && (
                  <tr>
                    <td colSpan={3} className="px-3 py-6 text-center text-secondary text-xs">No assets match the current filter</td>
                  </tr>
                )}
                {coverageRows.map((row, i) => (
                  <tr key={row.id} className={`border-b border-primary last:border-0 ${i % 2 === 1 ? 'bg-secondary/20' : ''}`}>
                    <td className="px-3 py-2 font-mono text-xs text-primary truncate max-w-xs">{row.name}</td>
                    <td className="px-3 py-2 text-xs text-secondary capitalize">{row.type}</td>
                    <td className="px-3 py-2">
                      {row.status === 'referenced' && (
                        <span className="inline-flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                          Referenced
                        </span>
                      )}
                      {row.status === 'missing' && (
                        <span className="inline-flex items-center gap-1 text-xs text-orange-600 dark:text-orange-400">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
                          Missing from disk
                        </span>
                      )}
                      {row.status === 'orphaned' && (
                        <span className="inline-flex items-center gap-1 text-xs text-gray-400 dark:text-gray-500">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" /></svg>
                          Unreferenced
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>)}
      </section>

      {/* Variable Coverage */}
      {variableCoverageRows.length > 0 && (
        <section className="mb-8">
          <h2 className="text-lg font-semibold mb-3">Variable Coverage</h2>

          {/* Coverage bar */}
          {(() => {
            const total = variableCoverageRows.length;
            const referenced = variableCoverageRows.filter(r => r.status === 'referenced').length;
            const unreferenced = total - referenced;
            const pct = total > 0 ? Math.round((referenced / total) * 100) : 0;
            return (
              <div className="bg-secondary rounded-lg p-4 mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-primary">Variables</span>
                  <span className="text-xs text-secondary tabular-nums">{referenced}/{total} referenced ({pct}%)</span>
                </div>
                <div className="h-2 bg-tertiary rounded-full overflow-hidden mb-2">
                  <div className="h-full bg-indigo-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
                </div>
                <div className="flex items-center gap-3 text-xs text-secondary">
                  {unreferenced > 0 ? (
                    <span className="text-gray-400">{unreferenced} unreferenced</span>
                  ) : (
                    <span className="text-green-500">All variables referenced</span>
                  )}
                </div>
              </div>
            );
          })()}

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <div className="flex rounded-md border border-primary overflow-hidden text-xs flex-none">
              {(['all', 'referenced', 'unreferenced'] as VariableCoverageStatusFilter[]).map(s => (
                <button
                  key={s}
                  onClick={() => setVarCoverageStatusFilter(s)}
                  aria-pressed={varCoverageStatusFilter === s}
                  className={`px-2.5 py-1 capitalize border-r border-primary last:border-0 transition-colors ${varCoverageStatusFilter === s ? 'bg-indigo-500 text-white' : 'bg-secondary text-secondary hover:bg-tertiary'}`}
                >
                  {s === 'all' ? 'All Status' : s}
                </button>
              ))}
            </div>
            <div className="relative flex-1 min-w-[140px]">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-secondary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Filter variables…"
                value={varCoverageTextFilter}
                onChange={e => setVarCoverageTextFilter(e.target.value)}
                className="w-full pl-7 pr-2 py-1 text-xs bg-secondary border border-primary rounded focus:outline-none focus:ring-1 focus:ring-indigo-400 text-primary placeholder:text-secondary"
              />
            </div>
            <span className="text-xs text-secondary flex-none">{filteredVariableCoverageRows.length} variable{filteredVariableCoverageRows.length !== 1 ? 's' : ''}</span>
          </div>

          {/* Coverage table */}
          <div className="overflow-x-auto rounded-lg border border-primary">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-tertiary border-b border-primary text-secondary text-xs">
                  <th className="px-3 py-2 text-left font-semibold cursor-pointer select-none" onClick={() => toggleVarCoverageSort('name')}>
                    Variable {varCoverageSortKey === 'name' ? (varCoverageSortDir === 'asc' ? '↑' : '↓') : <span className="opacity-40">↕</span>}
                  </th>
                  <th className="px-3 py-2 text-left font-semibold w-24">Type</th>
                  <th className="px-3 py-2 text-left font-semibold cursor-pointer select-none w-36" onClick={() => toggleVarCoverageSort('status')}>
                    Status {varCoverageSortKey === 'status' ? (varCoverageSortDir === 'asc' ? '↑' : '↓') : <span className="opacity-40">↕</span>}
                  </th>
                  <th className="px-3 py-2 text-left font-semibold w-28">Locations</th>
                </tr>
              </thead>
              <tbody>
                {filteredVariableCoverageRows.length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-3 py-6 text-center text-secondary text-xs">No variables match the current filter</td>
                  </tr>
                )}
                {filteredVariableCoverageRows.map((row, i) => (
                  <React.Fragment key={row.name}>
                    <tr
                      className={`border-b border-primary last:border-0 ${i % 2 === 1 ? 'bg-secondary/20' : ''} ${row.locations.length > 0 ? 'cursor-pointer hover:bg-indigo-50 dark:hover:bg-indigo-950/30' : ''}`}
                      onClick={row.locations.length > 0 ? () => toggleVarExpanded(row.name) : undefined}
                      onKeyDown={row.locations.length > 0 ? (e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          toggleVarExpanded(row.name);
                        }
                      } : undefined}
                      tabIndex={row.locations.length > 0 ? 0 : undefined}
                      role={row.locations.length > 0 ? 'button' : undefined}
                      aria-expanded={row.locations.length > 0 ? expandedVarNames.has(row.name) : undefined}
                    >
                      <td className="px-3 py-2 font-mono text-xs text-primary truncate max-w-xs">{row.name}</td>
                      <td className="px-3 py-2 text-xs text-secondary capitalize">{row.type}</td>
                      <td className="px-3 py-2">
                        {row.status === 'referenced' ? (
                          <span className="inline-flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                            Referenced
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs text-gray-400 dark:text-gray-500">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" /></svg>
                            Unreferenced
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-2 text-xs text-secondary">
                        {row.locations.length > 0 ? (
                          <span className="inline-flex items-center gap-1">
                            {row.locations.length} location{row.locations.length !== 1 ? 's' : ''}
                            <svg className={`w-3 h-3 transition-transform ${expandedVarNames.has(row.name) ? '' : '-rotate-90'}`} viewBox="0 0 12 12" fill="none">
                              <path d="M2 4L6 8L10 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                            </svg>
                          </span>
                        ) : '—'}
                      </td>
                    </tr>
                    {expandedVarNames.has(row.name) && row.locations.length > 0 && (
                      <tr className="border-b border-primary last:border-0 bg-tertiary/40">
                        <td colSpan={4} className="px-3 py-2">
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="text-secondary">
                                <th className="text-left font-semibold pb-1">File</th>
                                <th className="text-left font-semibold pb-1">Label</th>
                                <th className="text-right font-semibold pb-1 w-16">Lines</th>
                              </tr>
                            </thead>
                            <tbody>
                              {row.locations.map(loc => (
                                <tr
                                  key={`${loc.blockId}:${loc.label ?? ''}`}
                                  className={onOpenEditor ? 'cursor-pointer hover:text-indigo-500' : ''}
                                  onClick={onOpenEditor ? () => { onOpenEditor(loc.blockId, loc.firstLine); } : undefined}
                                  onKeyDown={onOpenEditor ? (e) => {
                                    if (e.key === 'Enter' || e.key === ' ') {
                                      e.preventDefault();
                                      onOpenEditor(loc.blockId, loc.firstLine);
                                    }
                                  } : undefined}
                                  tabIndex={onOpenEditor ? 0 : undefined}
                                  role={onOpenEditor ? 'button' : undefined}
                                >
                                  <td className="py-1 text-primary truncate max-w-[200px]" title={loc.filePath}>{loc.fileName}</td>
                                  <td className="py-1 font-mono text-primary">{loc.label ?? '—'}</td>
                                  <td className="py-1 text-right tabular-nums text-secondary">{loc.count}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {performanceMetrics && (
        <section className="mb-8">
          <h2 className="text-lg font-semibold mb-1">IDE Performance</h2>
          <p className="text-xs text-secondary mb-4">Internal metrics — measured since this session started. Not project content.</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <PerfStatCard
              label="Project Load"
              valueMs={performanceMetrics.lastLoadMs}
              targetMs={5000}
            />
            <PerfStatCard
              label="Last Analysis"
              valueMs={performanceMetrics.lastAnalysisMs}
            />
            <PerfStatCard
              label="Last Asset Scan"
              valueMs={performanceMetrics.lastScanMs}
            />
            <div className="bg-secondary rounded-lg p-4 flex flex-col gap-1">
              <p className="text-xs text-secondary uppercase tracking-wide font-medium">Canvas FPS</p>
              <p className="text-2xl font-bold tabular-nums">
                {fps !== null ? fps : <span className="text-secondary text-base font-normal">—</span>}
              </p>
              <p className="text-xs text-secondary">
                {fps !== null
                  ? fps >= 55 ? <span className="text-green-500">60 fps target ✓</span> : fps >= 30 ? <span className="text-yellow-500">below 60 fps</span> : <span className="text-red-500">low fps</span>
                  : 'live while tab is open'}
              </p>
            </div>
          </div>
          {performanceMetrics.memorySamples.length >= 2 && (
            <div className="bg-secondary rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-secondary uppercase tracking-wide font-medium">JS Heap Memory</p>
                <p className="text-xs text-secondary tabular-nums">
                  {performanceMetrics.memorySamples[performanceMetrics.memorySamples.length - 1].mb.toFixed(1)} MB now
                  {' · '}peak {Math.max(...performanceMetrics.memorySamples.map(s => s.mb)).toFixed(1)} MB
                </p>
              </div>
              <MemorySparkline samples={performanceMetrics.memorySamples} />
            </div>
          )}
        </section>
      )}
    </div>
  );
};

export default StatsView;
