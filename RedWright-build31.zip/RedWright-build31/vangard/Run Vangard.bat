@echo off
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Install Node.js 18 or newer, then open Vangard Studio again.
  echo https://nodejs.org/
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing Vangard Studio. This happens once and can take several minutes.
  call npm install
  if errorlevel 1 (
    echo npm install failed.
    pause
    exit /b 1
  )
)
if "%~1"=="" (
  call npm run electron:start
) else (
  call npm run electron:start -- --project "%~1"
)
if errorlevel 1 pause
