@echo off
setlocal
cd /d "%~dp0"
echo Close the RedGen window first, then press a key.
pause
set "REDGEN_SRC=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0replace.ps1"
if errorlevel 1 (
  pause
  exit /b 1
)
set /p LIVE=<"%~dp0updated-path.txt"
echo.
echo Starting:
echo %LIVE%
echo The title bar must say: RedGen build 34
echo.
cd /d "%LIVE%"
if exist __pycache__ rmdir /s /q __pycache__
call "Run RedGen.bat"
