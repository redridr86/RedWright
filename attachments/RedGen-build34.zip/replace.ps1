$src = $env:REDGEN_SRC
if (-not $src) { $src = Split-Path -Parent $MyInvocation.MyCommand.Path }
$src = $src.TrimEnd('\')
$newPy = Join-Path $src 'redgen.py'
if (-not (Select-String -LiteralPath $newPy -Pattern 'build 34' -Quiet)) {
    Write-Host 'This folder does not contain build 34. Unzip the download again and run this file from inside it.'
    exit 1
}

$skip = @('AppData', 'node_modules', '.git', '.venv', 'Windows', 'Program Files', 'Program Files (x86)', '$Recycle.Bin', 'Local Settings')
$roots = New-Object System.Collections.Generic.List[string]
$roots.Add($env:USERPROFILE)
foreach ($name in @('Desktop', 'Documents', 'Downloads')) {
    $one = Join-Path $env:USERPROFILE "OneDrive\$name"
    if (Test-Path -LiteralPath $one) { $roots.Add($one) }
}
$parent = Split-Path $src -Parent
if ($parent) { $roots.Add($parent) }
Get-PSDrive -PSProvider FileSystem | ForEach-Object { $roots.Add($_.Root) }

$dirs = New-Object System.Collections.Generic.List[string]
$seen = @{}
foreach ($root in $roots) {
    if (-not (Test-Path -LiteralPath $root)) { continue }
    $limit = 8
    if ($root -match '^[A-Za-z]:\\$') { $limit = 6 }
    $stack = New-Object System.Collections.Stack
    $stack.Push(@($root, 0))
    while ($stack.Count -gt 0) {
        $item = $stack.Pop()
        $dir = [string]$item[0]
        $depth = [int]$item[1]
        if ($seen.ContainsKey($dir)) { continue }
        $seen[$dir] = $true
        $py = Join-Path $dir 'redgen.py'
        if (Test-Path -LiteralPath $py) { $dirs.Add($dir) }
        if ($depth -ge $limit) { continue }
        try {
            foreach ($child in Get-ChildItem -LiteralPath $dir -Directory -ErrorAction SilentlyContinue) {
                if ($skip -contains $child.Name) { continue }
                $stack.Push(@($child.FullName, ($depth + 1)))
            }
        } catch {}
    }
}

$live = $null
$updated = 0
foreach ($dir in $dirs) {
    if ($dir.TrimEnd('\') -eq $src) { continue }
    Copy-Item -LiteralPath $newPy -Destination (Join-Path $dir 'redgen.py') -Force
    $tokenizer = Join-Path $src 'clip_tokenizer'
    if (Test-Path -LiteralPath $tokenizer) {
        Copy-Item -LiteralPath $tokenizer -Destination (Join-Path $dir 'clip_tokenizer') -Recurse -Force
    }
    foreach ($name in @('Run RedGen.bat', 'Run Red Gen.bat')) {
        $from = Join-Path $src $name
        if (Test-Path -LiteralPath $from) {
            Copy-Item -LiteralPath $from -Destination (Join-Path $dir $name) -Force
        }
    }
    $cache = Join-Path $dir '__pycache__'
    if (Test-Path -LiteralPath $cache) { Remove-Item -LiteralPath $cache -Recurse -Force -ErrorAction SilentlyContinue }
    Write-Host "Updated $dir"
    $updated++
    if (Test-Path -LiteralPath (Join-Path $dir '.venv')) { $live = $dir }
}

if (-not $live) {
    if ($updated -eq 0) {
        Write-Host 'No older copy was found. Starting this folder.'
    }
    $live = $src
}
Set-Content -LiteralPath (Join-Path $src 'updated-path.txt') -Value $live -Encoding ascii
Write-Host "Will start $live"
exit 0
